// @ts-check
/*
 * eslint.config.js – Regeln für die statische Code-Analyse
 *
 * Ausführen mit: npx ng lint
 * Geprüft werden TypeScript-Dateien (inkl. Inline-Templates) und HTML-Templates.
 * → Handbuch 12.1 „Statische Analyse mit ESLint“
 */
const eslint = require('@eslint/js');
const { defineConfig } = require('eslint/config');
const tseslint = require('typescript-eslint');
const angular = require('angular-eslint');

module.exports = defineConfig([
  // Regeln für TypeScript-Dateien
  {
    files: ['**/*.ts'],
    extends: [
      eslint.configs.recommended,
      tseslint.configs.recommended,
      tseslint.configs.stylistic,
      angular.configs.tsRecommended,
    ],
    // prüft auch Templates, die inline im @Component-Decorator stehen
    processor: angular.processInlineTemplates,
    rules: {
      // Direktiven-Selektoren: Attribut mit Präfix app in camelCase, z. B. appHighlight
      '@angular-eslint/directive-selector': [
        'error',
        {
          type: 'attribute',
          prefix: 'app',
          style: 'camelCase',
        },
      ],
      // Komponenten-Selektoren: Element mit Präfix app in kebab-case, z. B. app-customer-table
      '@angular-eslint/component-selector': [
        'error',
        {
          type: 'element',
          prefix: 'app',
          style: 'kebab-case',
        },
      ],
    },
  },
  // Regeln für HTML-Templates, inklusive Barrierefreiheit (z. B. label zu input)
  {
    files: ['**/*.html'],
    extends: [angular.configs.templateRecommended, angular.configs.templateAccessibility],
    rules: {},
  },
]);
