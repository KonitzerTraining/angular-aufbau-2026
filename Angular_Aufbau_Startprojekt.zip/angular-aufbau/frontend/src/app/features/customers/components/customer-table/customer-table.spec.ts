/*
 * customer-table.spec.ts – Unit-Test für die Kundentabelle
 *
 * Eine Presentational Component lässt sich besonders leicht testen:
 * Inputs setzen, Darstellung prüfen, Outputs abhören – ohne Service-Attrappen.
 *
 * → Handbuch 12.4 „Unit-Tests mit Vitest“
 * → Handbuch 11.7 „Smart und Presentational Components“
 */
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { LOCALE_ID } from '@angular/core';
import { registerLocaleData } from '@angular/common';
import localeDe from '@angular/common/locales/de';
import { CustomerTable } from './customer-table';
import { Customer } from '../../model/customer';

// Im Test gilt app.config.ts nicht – die deutschen Formate müssen hier
// ebenfalls registriert werden. → Handbuch 6.10 „Lokalisierung von Zahlen und Datum“
registerLocaleData(localeDe);

// Testdaten
const customers: Customer[] = [
  { id: 1, name: 'Tim', credit_limit: 2500 },
  { id: 2, name: 'Matt', credit_limit: 500 },
];

describe('CustomerTable', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [CustomerTable],
      // Router für routerLink, LOCALE_ID für die deutsche currency-Pipe
      providers: [provideRouter([]), { provide: LOCALE_ID, useValue: 'de-DE' }],
    });
  });

  it('zeigt eine Zeile pro Kunde mit deutschem Betrag', () => {
    const fixture = TestBed.createComponent(CustomerTable);
    // setInput(): setzt ein Signal-Input wie ein [data]="…" im Template
    fixture.componentRef.setInput('data', customers);
    // detectChanges(): Template jetzt darstellen
    fixture.detectChanges();
    const rows = (fixture.nativeElement as HTMLElement).querySelectorAll('tbody tr');
    expect(rows.length).toBe(2);
    expect(rows[0].textContent).toContain('2.500,00');
  });

  it('meldet die id beim Löschen', () => {
    // vi.spyOn(): ersetzt window.confirm, damit kein Dialog erscheint – Antwort "OK"
    vi.spyOn(window, 'confirm').mockReturnValue(true);
    const fixture = TestBed.createComponent(CustomerTable);
    fixture.componentRef.setInput('data', customers);
    fixture.detectChanges();
    let deletedId = 0;
    // ein output() lässt sich im Test wie ein Observable abonnieren
    fixture.componentInstance.deleteEvent.subscribe((id) => (deletedId = id));
    // Klick auf den ersten Löschen-Button simulieren
    (fixture.nativeElement as HTMLElement).querySelector<HTMLButtonElement>('button.btn-danger')!.click();
    expect(deletedId).toBe(1);
  });
});
