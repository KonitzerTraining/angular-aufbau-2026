import { afterNextRender, Component, effect, ElementRef, inject, input, output, viewChild } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Customer, NewCustomer } from '../../model/customer';

/**
 * Formular für Kunden – wird beim Anlegen und beim Bearbeiten verwendet
 *
 * Rolle: wiederverwendbare Presentational Component. Sie kennt weder Service
 * noch Router: Startwerte kommen über input() herein, die eingegebenen Daten
 * gehen über output() hinaus. Was mit den Daten passiert (POST oder PUT),
 * entscheiden die Smart Components CustomerNew und CustomerEdit.
 * Die Beschriftung des Absende-Buttons kommt per Content Projection.
 *
 * → Handbuch 10.3 „Das Kundenformular“
 * → Handbuch 10.7 „Startwerte beim Bearbeiten“
 * → Handbuch 11.1 „Ein Formular für Neu und Bearbeiten“
 * → Handbuch 11.7 „Smart und Presentational Components“
 */
@Component({
  selector: 'app-customer-form',
  // ReactiveFormsModule stellt formGroup, formControlName und ngSubmit bereit
  imports: [ReactiveFormsModule],
  templateUrl: './customer-form.html',
  styles: `
    /* Tailwind-Klassen für @apply bekannt machen (ohne Tailwind erneut einzubinden)
       → Handbuch 10.5 „Fehler verständlich anzeigen“ */
    @reference 'tailwindcss';

    /* roter Rahmen für ungültige Felder (Klasse per [class.invalid] gesetzt) */
    input.invalid {
      @apply border-red-500 focus:ring-red-200;
    }
    /* Fehlertext unter dem Feld */
    .error {
      @apply mt-1 mb-0 text-sm text-red-600;
    }
  `,
})
export class CustomerForm {
  /** Startwerte beim Bearbeiten */
  // optionales input(): beim Anlegen bleibt es undefined, beim Bearbeiten
  // bindet CustomerEdit [default]="customer.value()". → Handbuch 11.2 „Daten hinein: input()“
  readonly default = input<Customer>();
  /** liefert die Formulardaten beim Absenden */
  // output(): eigenes Ereignis, die Eltern-Komponente lauscht mit (customerSubmit)="…"
  // → Handbuch 11.3 „Ereignisse hinaus: output()“
  readonly customerSubmit = output<NewCustomer>();

  // FormBuilder erzeugt die FormGroup in Kurzschreibweise: je Feld [Startwert, Validatoren].
  // nonNullable: Felder werden beim Zurücksetzen wieder zum Startwert statt null –
  // dadurch sind die Typen string und number statt string | null.
  // → Handbuch 10.2 „Die Bausteine“, → Handbuch 10.3 „Das Kundenformular“
  readonly form = inject(FormBuilder).nonNullable.group({
    // Validators: eingebaute Prüfregeln; das Feld ist ungültig, sobald eine Regel verletzt ist
    name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(255)]],
    credit_limit: [0, [Validators.required, Validators.min(0), Validators.max(1e9)]],
  });

  /** Referenz auf das Namensfeld im Template (#nameInput) */
  // viewChild() liefert ein Signal mit dem Element, sobald das Template dargestellt ist
  private readonly nameInput = viewChild<ElementRef<HTMLInputElement>>('nameInput');

  constructor() {
    // nach der ersten Darstellung: Fokus ins Namensfeld
    // afterNextRender() läuft einmal, nachdem Angular das DOM erzeugt hat –
    // vorher gäbe es das input-Element noch nicht. → Handbuch 7.9 „Lebenszyklus“
    afterNextRender(() => this.nameInput()?.nativeElement.focus());

    // Startwerte übernehmen, sobald sie da sind
    // effect() reagiert auf das Input-Signal default(): Kommt der Kunde (beim
    // Bearbeiten) an, werden seine Werte ins Formular geschrieben.
    // patchValue() übernimmt passende Felder und ignoriert zusätzliche wie id.
    // → Handbuch 10.7 „Startwerte beim Bearbeiten“
    effect(() => {
      const customer = this.default();
      if (customer) {
        this.form.patchValue(customer);
      }
    });
  }

  /** true, wenn das Feld ungültig ist und bereits bearbeitet wurde */
  // touched: Das Feld hatte schon einmal den Fokus. So erscheinen Fehler nicht
  // schon beim Öffnen des Formulars. → Handbuch 10.5 „Fehler verständlich anzeigen“
  isInvalid(field: 'name' | 'credit_limit'): boolean {
    const control = this.form.controls[field];
    return control.invalid && control.touched;
  }

  // → Handbuch 10.6 „Absenden“
  submitHandler() {
    if (this.form.invalid) {
      // alle Felder als "berührt" markieren, damit alle Fehlermeldungen erscheinen
      this.form.markAllAsTouched();
      return;
    }
    // getRawValue(): alle Werte als typisiertes Objekt { name, credit_limit }
    this.customerSubmit.emit(this.form.getRawValue());
  }
}
