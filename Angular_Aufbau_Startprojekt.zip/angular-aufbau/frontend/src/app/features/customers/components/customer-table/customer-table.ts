import { Component, input, output } from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Customer } from '../../model/customer';
import { Highlight } from '../../../../directives/highlight';

/**
 * Tabelle mit Kunden; meldet Löschwünsche an die Eltern-Komponente
 *
 * Rolle: Presentational Component – kein inject(), kein Service. Sie bekommt
 * die Kunden über input() und meldet das Löschen über output(). Das Löschen
 * selbst (HTTP-Aufruf) erledigt die Smart Component CustomerList.
 * Wiederverwendet auf der Signals-Seite.
 *
 * → Handbuch 9.7 „Daten in der Komponente darstellen“
 * → Handbuch 11.3 „Ereignisse hinaus: output()“
 * → Handbuch 11.7 „Smart und Presentational Components“
 */
@Component({
  selector: 'app-customer-table',
  imports: [CurrencyPipe, RouterLink, Highlight],
  templateUrl: './customer-table.html',
})
export class CustomerTable {
  /** anzuzeigende Kunden */
  // input.required(): ohne [data]="…" meldet der Compiler einen Fehler
  // → Handbuch 11.2 „Daten hinein: input()“
  readonly data = input.required<Customer[]>();
  /** liefert die id des zu löschenden Kunden */
  // output<number>(): die Eltern-Komponente erhält die id als $event
  readonly deleteEvent = output<number>();

  deleteEntry(customer: Customer) {
    // Sicherheitsabfrage des Browsers; erst bei "OK" wird das Ereignis ausgelöst
    if (confirm(`Kunde „${customer.name}“ wirklich löschen?`)) {
      // emit() sendet den Wert an alle, die mit (deleteEvent)="…" lauschen
      this.deleteEvent.emit(customer.id);
    }
  }
}
