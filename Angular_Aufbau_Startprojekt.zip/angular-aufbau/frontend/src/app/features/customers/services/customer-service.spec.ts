/*
 * customer-service.spec.ts – Unit-Test für den CustomerService
 *
 * Der Test spricht NICHT mit dem echten Server: provideHttpClientTesting()
 * fängt alle Anfragen ab, und der HttpTestingController beantwortet sie mit
 * Testdaten. So laufen die Tests schnell und ohne laufendes Backend.
 *
 * → Handbuch 12.4 „Unit-Tests mit Vitest“
 * → Handbuch 9.5 „Der CustomerService“
 */
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { CUSTOMER_URL, CustomerService } from './customer-service';

describe('CustomerService', () => {
  let service: CustomerService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      // Reihenfolge wichtig: erst den HttpClient, dann die Test-Variante darüber
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    // TestBed.inject() holt Instanzen aus der Dependency Injection des Tests
    service = TestBed.inject(CustomerService);
    http = TestBed.inject(HttpTestingController);
  });

  // verify(): schlägt fehl, wenn noch unbeantwortete Anfragen offen sind
  afterEach(() => http.verify());

  it('lädt alle Kunden per GET', () => {
    let count = 0;
    // subscribe() startet die Anfrage – ohne subscribe() schickt HttpClient nichts ab
    service.getAll().subscribe((customers) => (count = customers.length));
    // genau eine Anfrage an diese URL erwartet
    const request = http.expectOne(CUSTOMER_URL);
    expect(request.request.method).toBe('GET');
    // flush(): beantwortet die Anfrage mit Testdaten – erst jetzt läuft der subscribe-Callback
    request.flush([{ id: 1, name: 'Tim', credit_limit: 2500 }]);
    expect(count).toBe(1);
  });

  it('löscht per DELETE', () => {
    service.deleteById(7).subscribe();
    const request = http.expectOne(CUSTOMER_URL + 7);
    expect(request.request.method).toBe('DELETE');
    request.flush(null);
  });
});
