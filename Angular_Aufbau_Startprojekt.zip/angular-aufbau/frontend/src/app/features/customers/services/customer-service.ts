import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
// immer environment.ts importieren – bei ng serve tauscht die CLI den Inhalt aus
import { environment } from '../../../../environments/environment';
import { Customer, NewCustomer } from '../model/customer';

/** Basis-URL der Ressource */
// exportiert, damit auch httpResource in CustomerEdit und der Test dieselbe Adresse nutzen
// → Handbuch 9.2 „Die Adresse der API: Environments“
export const CUSTOMER_URL = environment.api + 'customers/';

/**
 * Zugriff auf die REST-API für Kunden
 *
 * Rolle: Service. Er kapselt alle HTTP-Aufrufe für Kunden, damit die
 * Komponenten nichts über URLs und HTTP-Methoden wissen müssen. Verwendet von
 * CustomerList, CustomerNew, CustomerEdit und der Signals-Seite.
 *
 * Jede Methode liefert ein Observable: Die Anfrage startet erst mit subscribe(),
 * die Antwort kommt später (asynchron).
 *
 * → Handbuch 9.5 „Der CustomerService“
 * → Handbuch 9.6 „Observables: die Antwort kommt später“
 * → Handbuch 5.6 „Dependency Injection und inject()“
 */
// providedIn: 'root' – Angular erzeugt genau eine Instanz für die ganze
// Anwendung (Singleton), sobald sie zum ersten Mal per inject() angefordert wird.
@Injectable({ providedIn: 'root' })
export class CustomerService {
  // inject(): Angular liefert den HttpClient, der in app.config.ts per
  // provideHttpClient() bereitgestellt wurde (Dependency Injection).
  private readonly http = inject(HttpClient);

  /** Alle Kunden laden (GET /customers/) */
  // get<Customer[]>: der Typparameter sagt TypeScript, welche Daten zurückkommen
  // (geprüft wird das zur Laufzeit nicht).
  getAll(): Observable<Customer[]> {
    return this.http.get<Customer[]>(CUSTOMER_URL);
  }

  /** Einen Kunden laden (GET /customers/:id) */
  getById(id: number): Observable<Customer> {
    return this.http.get<Customer>(CUSTOMER_URL + id);
  }

  /** Neuen Kunden anlegen (POST /customers/) */
  // Der Server vergibt die id und schickt den vollständigen Kunden zurück
  postOne(customer: NewCustomer): Observable<Customer> {
    return this.http.post<Customer>(CUSTOMER_URL, customer);
  }

  /** Kunden ändern (PUT /customers/:id) */
  putOne(customer: Customer): Observable<Customer> {
    return this.http.put<Customer>(CUSTOMER_URL + customer.id, customer);
  }

  /** Kunden löschen (DELETE /customers/:id) */
  // → Handbuch 9.9 „Löschen“
  deleteById(id: number): Observable<unknown> {
    return this.http.delete(CUSTOMER_URL + id);
  }
}
