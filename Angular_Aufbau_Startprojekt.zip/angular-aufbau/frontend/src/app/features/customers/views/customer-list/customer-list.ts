import { Component, inject, OnInit, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Customer } from '../../model/customer';
import { CustomerService } from '../../services/customer-service';
import { CustomerTable } from '../../components/customer-table/customer-table';
import { LoadingIndicator } from '../../../../components/loading-indicator/loading-indicator';
import { MessageBox } from '../../../../components/message-box/message-box';

/**
 * Liste aller Kunden mit Lade- und Fehlerzustand
 *
 * Rolle: Seite (Route /customers) und Smart Component. Sie holt sich den
 * CustomerService per inject(), lädt die Kunden, hält den Zustand in Signals
 * und reagiert auf das Löschen-Ereignis der CustomerTable.
 *
 * Variante "klassisch": subscribe() in ngOnInit. Zum Vergleich lädt
 * CustomerEdit deklarativ mit httpResource.
 *
 * → Handbuch 9.7 „Daten in der Komponente darstellen“
 * → Handbuch 9.8 „Ladezustand und Fehler anzeigen“
 * → Handbuch 9.9 „Löschen“
 * → Handbuch 11.7 „Smart und Presentational Components“
 */
@Component({
  selector: 'app-customer-list',
  imports: [RouterLink, CustomerTable, LoadingIndicator, MessageBox],
  templateUrl: './customer-list.html',
})
export class CustomerList implements OnInit {
  // Dependency Injection: Angular liefert die eine Instanz des Services
  // → Handbuch 5.6 „Dependency Injection und inject()“
  private readonly customerService = inject(CustomerService);

  // Zustand als Signals: Die Serverantwort kommt asynchron – in einer zoneless
  // Anwendung bemerkt Angular die Änderung nur über ein Signal.
  // → Handbuch 7.6 „Zoneless: warum normale Felder nicht reichen“
  readonly customers = signal<Customer[]>([]);
  readonly loading = signal(false);
  readonly errorMessage = signal<string | null>(null);

  // ngOnInit(): Lifecycle-Hook, läuft einmal nach dem Erzeugen der Komponente
  // → Handbuch 5.8 „Lebenszyklus in Kürze“
  ngOnInit() {
    this.loadCustomers();
  }

  loadCustomers() {
    this.loading.set(true);
    this.errorMessage.set(null);
    // subscribe() startet die HTTP-Anfrage. next läuft bei Erfolg, error bei
    // einem Fehler (z. B. Server nicht erreichbar).
    // → Handbuch 9.6 „Observables: die Antwort kommt später“
    this.customerService.getAll().subscribe({
      next: (customers) => {
        this.customers.set(customers);
        this.loading.set(false);
      },
      error: (e: Error) => {
        this.errorMessage.set('Kunden konnten nicht geladen werden: ' + e.message);
        this.loading.set(false);
      },
    });
  }

  // Wird über (deleteEvent) aus der CustomerTable aufgerufen
  deleteCustomer(id: number) {
    this.errorMessage.set(null);
    this.customerService.deleteById(id).subscribe({
      // Nach erfolgreichem Löschen die Liste lokal aktualisieren, statt neu zu laden.
      // filter() erzeugt ein NEUES Array – nötig, damit das Signal die Änderung erkennt.
      // → Handbuch 7.4 „Objekte und Arrays unveränderlich ändern“
      next: () => this.customers.update((list) => list.filter((c) => c.id !== id)),
      error: (e: Error) => this.errorMessage.set('Löschen fehlgeschlagen: ' + e.message),
    });
  }
}
