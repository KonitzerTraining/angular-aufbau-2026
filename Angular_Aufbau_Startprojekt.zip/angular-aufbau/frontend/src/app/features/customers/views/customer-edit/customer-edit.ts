import { Component, inject, input, signal } from '@angular/core';
import { httpResource } from '@angular/common/http';
import { Router, RouterLink } from '@angular/router';
import { Customer, NewCustomer } from '../../model/customer';
import { CUSTOMER_URL, CustomerService } from '../../services/customer-service';
import { CustomerForm } from '../../components/customer-form/customer-form';
import { LoadingIndicator } from '../../../../components/loading-indicator/loading-indicator';
import { MessageBox } from '../../../../components/message-box/message-box';

/**
 * Bestehenden Kunden bearbeiten
 *
 * Rolle: Seite (Route /customers/edit/:customerId) und Smart Component.
 * Sie liest die Kunden-ID aus der URL, lädt den Kunden deklarativ mit
 * httpResource, reicht ihn als Startwert an das CustomerForm weiter und
 * speichert die Änderungen per PUT über den CustomerService.
 *
 * → Handbuch 10.10 „Bearbeiten: Laden, Ändern, Speichern“
 * → Handbuch 9.10 „Deklarativ laden mit httpResource“
 * → Handbuch 8.6 „Parameter-Mitnahme“
 * → Handbuch 11.7 „Smart und Presentational Components“
 */
@Component({
  selector: 'app-customer-edit',
  imports: [RouterLink, CustomerForm, LoadingIndicator, MessageBox],
  templateUrl: './customer-edit.html',
})
export class CustomerEdit {
  private readonly customerService = inject(CustomerService);
  private readonly router = inject(Router);

  /** Routenparameter :customerId – dank withComponentInputBinding() */
  // Der Name muss genau zum Platzhalter in customers.routes.ts passen.
  // Routenparameter sind immer Texte, daher string. → Handbuch 8.6 „Parameter-Mitnahme“
  readonly customerId = input.required<string>();

  /** lädt den Kunden und lädt neu, wenn sich customerId ändert */
  // httpResource(): Die Funktion liefert die URL. Weil sie das Signal customerId()
  // liest, lädt die Resource automatisch neu, sobald sich die ID ändert – ganz
  // ohne subscribe(). Ergebnis und Zustand stehen als Signals bereit:
  // value(), isLoading(), error(), hasValue().
  // → Handbuch 9.10 „Deklarativ laden mit httpResource“
  readonly customer = httpResource<Customer>(() => CUSTOMER_URL + this.customerId());

  readonly errorMessage = signal<string | null>(null);

  // Wird über (customerSubmit) aus dem CustomerForm aufgerufen
  updateCustomer(data: NewCustomer) {
    // Das Formular liefert nur name und credit_limit; die id kommt aus der URL.
    // Number(): Routenparameter (Text) in eine Zahl umwandeln.
    const customer: Customer = { ...data, id: Number(this.customerId()) };
    this.errorMessage.set(null);
    // Speichern bleibt ein klassischer Aufruf mit subscribe() – httpResource ist nur zum Laden gedacht
    this.customerService.putOne(customer).subscribe({
      // → Handbuch 10.9 „Programmatisches Routing“
      next: () => this.router.navigate(['/customers']),
      error: (e: Error) => this.errorMessage.set('Speichern fehlgeschlagen: ' + e.message),
    });
  }
}
