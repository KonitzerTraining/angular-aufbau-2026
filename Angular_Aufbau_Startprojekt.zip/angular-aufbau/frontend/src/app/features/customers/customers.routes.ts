/*
 * customers.routes.ts – die Routen des Kundenbereichs
 *
 * app.routes.ts lädt diese Tabelle per loadChildren erst, wenn eine URL mit
 * /customers aufgerufen wird. Alle hier importierten Komponenten landen damit
 * in einem eigenen, nachgeladenen JavaScript-Chunk.
 *
 * Ergebnis:
 *   /customers                  → Customers + CustomerList
 *   /customers/new              → Customers + CustomerNew
 *   /customers/edit/:customerId → Customers + CustomerEdit
 *
 * → Handbuch 8.4 „Lazy Loading“
 * → Handbuch 8.5 „Verschachteltes Routing und Router Outlets“
 * → Handbuch 8.8 „Übersicht der Routen im CRM“
 */
import { Routes } from '@angular/router';
import { Customers } from './customers';
import { CustomerList } from './views/customer-list/customer-list';
import { CustomerNew } from './views/customer-new/customer-new';
import { CustomerEdit } from './views/customer-edit/customer-edit';

/**
 * Routen des Kundenbereichs (per loadChildren nachgeladen)
 */
export const customerRoutes: Routes = [
  {
    // '' bezieht sich auf das Präfix 'customers' aus app.routes.ts
    path: '',
    // Rahmen-Komponente mit eigenem <router-outlet /> für die Kind-Routen
    component: Customers,
    // children: verschachtelte Routen – sie erscheinen im router-outlet von Customers
    children: [
      { path: '', component: CustomerList, title: 'CRM – Kunden' },
      { path: 'new', component: CustomerNew, title: 'CRM – Neuer Kunde' },
      // :customerId ist ein Routenparameter (Platzhalter für die Kunden-ID).
      // Dank withComponentInputBinding() kommt er im input() customerId an.
      // → Handbuch 8.6 „Parameter-Mitnahme“
      { path: 'edit/:customerId', component: CustomerEdit, title: 'CRM – Kunde bearbeiten' },
    ],
  },
];
