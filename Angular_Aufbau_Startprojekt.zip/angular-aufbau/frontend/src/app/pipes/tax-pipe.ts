import { Pipe, PipeTransform } from '@angular/core';

/**
 * Rechnet einen Nettobetrag in einen Bruttobetrag um
 *
 * Verwendung: `{{ 100 | tax }}` oder `{{ 100 | tax: 7 }}`
 *
 * Eigene Pipe, erzeugt mit `ng generate pipe pipes/tax`. Im CRM wird sie auf
 * der Template-Syntax-Seite verwendet (verkettet mit der currency-Pipe).
 *
 * → Handbuch 6.11 „Eigene Pipe: TaxPipe“
 */
// name: unter diesem Namen steht die Pipe im Template hinter dem senkrechten Strich
@Pipe({ name: 'tax' })
export class TaxPipe implements PipeTransform {
  // transform() bekommt den Wert links vom Strich; weitere Parameter folgen nach
  // dem Doppelpunkt. rate = 19 ist ein Standardwert, falls keiner angegeben ist.
  // Die Pipe ist "pure": Angular ruft sie nur neu auf, wenn sich die Eingabe ändert.
  transform(value: number, rate = 19): number {
    return value * (1 + rate / 100);
  }
}
