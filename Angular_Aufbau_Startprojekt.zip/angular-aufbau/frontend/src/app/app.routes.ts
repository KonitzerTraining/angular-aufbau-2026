/*
 * app.routes.ts – die Routen-Tabelle der Anwendung
 *
 * Jede Route ordnet einem URL-Pfad eine Komponente zu. Der Router stellt die
 * passende Komponente im <router-outlet /> der Root-Komponente (app.html) dar.
 * Eingebunden wird die Tabelle in app.config.ts über provideRouter(routes).
 *
 * → Handbuch 4.4 „Routen festlegen“
 * → Handbuch 8.2 „Alle Eigenschaften einer Route“
 * → Handbuch 8.4 „Lazy Loading“
 * → Handbuch 8.8 „Übersicht der Routen im CRM“
 */
import { Routes } from '@angular/router';
// Diese drei Seiten werden direkt importiert und landen damit im Haupt-Bundle.
import { StartPage } from './pages/start-page/start-page';
import { AboutPage } from './pages/about-page/about-page';
import { NotFoundPage } from './pages/not-found-page/not-found-page';
import { LoginPage } from './pages/login-page/login-page';

export const routes: Routes = [
  // Leerer Pfad (http://localhost:4200/) → weiter auf /start.
  // pathMatch: 'full' ist bei redirectTo mit leerem Pfad nötig, sonst würde
  // '' als Präfix auf JEDE URL passen. → Handbuch 8.2 „Alle Eigenschaften einer Route“
  { path: '', redirectTo: 'start', pathMatch: 'full' },
  // title setzt den Text im Browser-Tab, wenn die Route aktiv ist
  { path: 'start', component: StartPage, title: 'CRM – Start' },
  {
    path: 'template-syntax',
    title: 'CRM – Template-Syntax',
    // Lazy Loading einer einzelnen Komponente: import() lädt die Datei erst,
    // wenn die Route zum ersten Mal aufgerufen wird (eigener JavaScript-Chunk).
    // → Handbuch 8.4 „Lazy Loading“
    loadComponent: () => import('./pages/template-syntax/template-syntax').then((m) => m.TemplateSyntax),
  },
  {
    path: 'signals',
    title: 'CRM – Signals',
    loadComponent: () => import('./pages/signals/signals').then((m) => m.Signals),
  },
  {
    path: 'customers',
    // Lazy Loading eines ganzen Bereichs: loadChildren lädt eine weitere
    // Routen-Tabelle (customers.routes.ts) samt aller Kunden-Komponenten nach.
    // → Handbuch 8.4 „Lazy Loading“, → Handbuch 8.5 „Verschachteltes Routing und Router Outlets“
    loadChildren: () => import('./features/customers/customers.routes').then((m) => m.customerRoutes),
  },
  // Weiterleitung: alter Pfad /dashboard führt jetzt zur Kundenliste
  { path: 'dashboard', redirectTo: 'customers' },
  { path: 'about', component: AboutPage, title: 'CRM – Über uns' },
  // Startprojekt: Anmeldeseite, noch ohne Logik (die Anmeldung mit dem AuthStore folgt im Seminar)
  { path: 'login', component: LoginPage, title: 'CRM – Anmelden' },
  // immer als letzte Route
  // '**' (Wildcard) passt auf jede URL. Der Router prüft die Routen von oben
  // nach unten – stünde diese Route weiter oben, käme keine andere mehr zum Zug.
  { path: '**', component: NotFoundPage, title: 'CRM – Seite nicht gefunden' },
];
