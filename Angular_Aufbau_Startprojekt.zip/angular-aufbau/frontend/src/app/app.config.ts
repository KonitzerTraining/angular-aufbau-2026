/*
 * app.config.ts – die globale Konfiguration der Anwendung
 *
 * Hier wird festgelegt, welche Dienste (Provider) in der ganzen Anwendung zur
 * Verfügung stehen: Router, HttpClient und die deutsche Sprache für Pipes.
 * main.ts übergibt dieses Objekt an bootstrapApplication().
 *
 * → Handbuch 3.4 „Bootstrapping: der Start der Anwendung“
 * → Handbuch 9.3 „HttpClient einschalten“
 * → Handbuch 6.10 „Lokalisierung von Zahlen und Datum“
 * → Handbuch 8.6 „Parameter-Mitnahme“
 */
import { ApplicationConfig, LOCALE_ID, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter, withComponentInputBinding } from '@angular/router';
import { provideHttpClient, withFetch } from '@angular/common/http';
import { registerLocaleData } from '@angular/common';
import localeDe from '@angular/common/locales/de';

import { routes } from './app.routes';

// Die deutschen Formatregeln (Dezimalkomma, Tausenderpunkt, Monatsnamen) bringt
// Angular nicht von Haus aus mit – sie werden hier einmalig registriert.
// → Handbuch 6.10 „Lokalisierung von Zahlen und Datum“
registerLocaleData(localeDe);

export const appConfig: ApplicationConfig = {
  providers: [
    // leitet nicht abgefangene Fehler im Browser an Angulars ErrorHandler weiter
    provideBrowserGlobalErrorListeners(),
    // Router mit den Routen aus app.routes.ts einschalten.
    // withComponentInputBinding(): Routenparameter wie :customerId kommen
    // automatisch in ein gleichnamiges input() der Komponente (siehe CustomerEdit).
    // → Handbuch 4.4 „Routen festlegen“, → Handbuch 8.6 „Parameter-Mitnahme“
    provideRouter(routes, withComponentInputBinding()),
    // HttpClient bereitstellen, damit Services per inject(HttpClient) Daten laden können.
    // withFetch(): Anfragen laufen über die moderne fetch-API des Browsers statt XMLHttpRequest.
    // → Handbuch 9.3 „HttpClient einschalten“
    provideHttpClient(withFetch()),
    // Standard-Sprache für alle Pipes (number, currency, date): 23.004,60 € statt €23,004.60
    // → Handbuch 6.10 „Lokalisierung von Zahlen und Datum“
    { provide: LOCALE_ID, useValue: 'de-DE' },
  ],
};
