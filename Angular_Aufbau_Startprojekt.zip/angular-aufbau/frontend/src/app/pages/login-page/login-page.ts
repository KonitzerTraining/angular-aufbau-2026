import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';

/**
 * Anmeldeseite – Ausgangspunkt für den Auth-Teil der Aufbauschulung
 *
 * Stand im Startprojekt: Das Formular prüft nur, ob beide Felder ausgefüllt
 * sind. Es meldet noch niemanden an. Im Seminar kommt hinzu:
 *   - AuthService (Mock gegen /users) und AuthStore mit dem NgRx SignalStore
 *   - Navigation abhängig vom Login-Zustand, funktionaler Guard für
 *     /customers, Weiterleitung nach Login und Logout
 *
 * Grundlagen dazu: → Handbuch Grundlagen 10.2 „Die Bausteine“ (Reactive Forms)
 */
@Component({
  selector: 'app-login-page',
  imports: [ReactiveFormsModule],
  templateUrl: './login-page.html',
})
export class LoginPage {
  private fb = inject(FormBuilder);

  // nonNullable: reset() setzt auf '' statt auf null zurück
  readonly form = this.fb.nonNullable.group({
    username: ['', Validators.required],
    password: ['', Validators.required],
  });

  // Hinweistext nach dem Absenden – wird im Seminar durch den echten Login ersetzt
  readonly hint = signal('');

  submitHandler(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    // TODO: hier den Login über den AuthStore aufrufen statt Hinweis anzeigen
    this.hint.set(`Anmeldung für „${this.form.getRawValue().username}“ ist noch nicht umgesetzt.`);
  }
}
