import { TestBed } from '@angular/core/testing';
import { LoginPage } from './login-page';

describe('LoginPage', () => {
  it('meldet ein leeres Formular als ungültig und zeigt keinen Hinweis', async () => {
    const fixture = TestBed.createComponent(LoginPage);
    await fixture.whenStable();
    const page = fixture.componentInstance;

    page.submitHandler();

    expect(page.form.invalid).toBe(true);
    expect(page.hint()).toBe('');
  });

  it('zeigt nach dem Absenden einen Hinweis, solange der Login fehlt', async () => {
    const fixture = TestBed.createComponent(LoginPage);
    await fixture.whenStable();
    const page = fixture.componentInstance;

    page.form.setValue({ username: 'anna', password: 'geheim' });
    page.submitHandler();

    expect(page.hint()).toContain('anna');
  });
});
