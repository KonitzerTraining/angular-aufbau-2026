# CRM – Referenzprojekt „Angular Grundlagen“

Kundenverwaltung mit Angular 22, Tailwind CSS 4 und einer REST-API aus json-server.

## Starten

```bash
# Terminal 1 – Backend (Ordner ../backend)
npm install
npm start          # http://localhost:3001/customers

# Terminal 2 – Frontend (dieser Ordner)
npm install
npm start          # http://localhost:4200
```

## Befehle

| Befehl | Zweck |
|---|---|
| `npm start` | Entwicklungsserver mit Live Reload |
| `npm run build` | Produktions-Build nach `dist/frontend/browser` |
| `npm test` | Unit-Tests mit Vitest (9 Tests) |
| `npm run lint` | Codequalität mit ESLint |
| `npm run preview` | gebauten Stand (`ng build`) mit http-server auf Port 8080 testen; API-Anfragen gehen an das Backend |

## Aufbau

- `src/styles.css` – Tailwind, Basisstile (`@layer base`), Button-Klassen (`@layer components`)
- `src/app/app.routes.ts` – Routen, der Kundenbereich wird per `loadChildren` nachgeladen
- `src/app/navigation` – Hauptnavigation
- `src/app/pages` – einfache Seiten: `start-page`, `about-page`, `not-found-page`, Übungsseiten `template-syntax`, `signals`
- `src/app/features/customers` – Kundenbereich mit `views` (`customer-list`, `customer-new`, `customer-edit`), `components` (`customer-table`, `customer-form`), `model`, `services`, `customers.routes.ts`
- `src/environments` – Adresse der API für Entwicklung und Produktion
