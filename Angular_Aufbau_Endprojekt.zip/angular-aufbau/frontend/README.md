# CRM – Frontend

Kundenverwaltung mit Angular 22, Tailwind CSS 4, NgRx SignalStore und einer REST-API aus json-server. Überblick, Stände und alle Befehle stehen in der [README im Wurzelordner](../README.md), die Architektur in [src/app/ARCHITEKTUR.md](src/app/ARCHITEKTUR.md).

## Starten

```bash
# Terminal 1 – Backend (Ordner ../backend)
npm install
npm start          # http://localhost:3001/customers

# Terminal 2 – Frontend (dieser Ordner)
npm install
npm start          # http://localhost:4200
```
