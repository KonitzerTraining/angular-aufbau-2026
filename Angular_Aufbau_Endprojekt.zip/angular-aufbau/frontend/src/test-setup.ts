/*
 * test-setup.ts – läuft vor jeder Testdatei (angular.json → test → setupFiles)
 *
 * Gemeinsame Vorbereitung für alle Unit-Tests an einer Stelle, statt sie in
 * jede *.spec.ts zu kopieren.
 *
 * → Aufbau-Handbuch „Unit-Tests mit Vitest“ (Testaufbau und Organisation)
 */
import { registerLocaleData } from '@angular/common';
import localeDe from '@angular/common/locales/de';

// Deutsche Zahlen- und Datumsformate auch im Test (app.config.ts gilt hier nicht)
registerLocaleData(localeDe);

// Nach jedem Test alle Spies und Mocks zurücksetzen: Ein vi.spyOn(window, 'confirm')
// aus Test A darf Test B nicht beeinflussen. Tests müssen unabhängig voneinander
// und in beliebiger Reihenfolge laufen.
afterEach(() => {
  vi.restoreAllMocks();
});
