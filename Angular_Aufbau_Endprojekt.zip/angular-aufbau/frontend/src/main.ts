/*
 * main.ts – der Einstiegspunkt der Anwendung
 *
 * Diese Datei führt der Browser als Erstes aus (die CLI trägt sie in angular.json
 * als "browser"-Einstieg ein). Sie startet die Root-Komponente App mit der
 * Konfiguration aus app.config.ts. Angular sucht dann in index.html das Element
 * <app-root> und stellt dort die Anwendung dar.
 *
 * → Handbuch 3.4 „Bootstrapping: der Start der Anwendung“
 * → Handbuch 3.5 „Die Projektstruktur“
 */
import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { App } from './app/app';

// bootstrapApplication() startet eine Standalone-Anwendung ohne NgModule:
// 1. Argument = Root-Komponente, 2. Argument = globale Provider (Router, HttpClient …).
// → Handbuch 3.3 „Standalone Components oder modularer Aufbau“
bootstrapApplication(App, appConfig)
  // Fehler beim Start (z. B. ein fehlender Provider) landen in der Browser-Konsole
  .catch((err) => console.error(err));
