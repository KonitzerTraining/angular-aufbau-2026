import { Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
// core darf Features über ihre öffentliche Schnittstelle verwenden
import { AuthStore } from '@features/auth';

/**
 * Hauptnavigation; der Markenname wird per Content Projection übergeben
 *
 * Rolle: Layout-Komponente, die in der Root-Komponente (app.html) oberhalb des
 * router-outlet steht und damit auf jeder Seite sichtbar ist.
 *
 * → Handbuch 4.5 „Die Navigation“
 * → Handbuch 8.3 „Mehr über Links“
 * → Handbuch 5.5 „Styles und Kapselung“
 *
 * Die Navigation hängt vom Login-Zustand im AuthStore ab:
 * „Kunden“ erscheint nur nach der Anmeldung, rechts stehen Name und
 * „Abmelden“ bzw. „Anmelden“. Abmelden ruft nur authStore.logout() auf –
 * die Weiterleitung zur Anmeldeseite erledigt der Store selbst.
 * → Aufbau-Handbuch „Den Store verwenden: Navigation und Guards“ (State-abhängige Navigationspunkte)
 *
 * Ablage: core/layout – gehört zum Rahmen der Anwendung, gibt es genau einmal.
 * → Aufbau-Handbuch „Standalone-Feature-Architektur“
 */
@Component({
  selector: 'app-navigation',
  // RouterLink und RouterLinkActive sind Direktiven und müssen importiert werden,
  // sonst wären routerLink und routerLinkActive im Template unbekannte Attribute.
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './navigation.html',
  // Komponenten-Styles gelten dank View Encapsulation nur für diese Komponente.
  // → Handbuch 5.5 „Styles und Kapselung“
  styles: `
    /* @reference macht die Tailwind-Klassen für @apply bekannt, ohne Tailwind
       ein zweites Mal in das CSS dieser Komponente zu kopieren.
       → Handbuch 3.7 „Layout-Framework verwenden: Tailwind CSS“ */
    @reference 'tailwindcss';

    /* Grundaussehen eines Menüpunkts */
    .nav-link {
      @apply rounded-md px-3 py-2 text-sm text-slate-600 no-underline hover:bg-slate-100 hover:text-slate-900;
    }
    /* Die Klasse "active" setzt routerLinkActive beim Link der aktuellen Seite */
    .nav-link.active {
      @apply bg-blue-50 font-medium text-blue-700;
    }
  `,
})
export class Navigation {
  private readonly authStore = inject(AuthStore);

  // Signals aus dem AuthStore – das Template aktualisiert sich von selbst
  protected readonly user = this.authStore.user;
  protected readonly isLoggedIn = this.authStore.isLoggedIn;

  protected logout(): void {
    this.authStore.logout();
  }
}
