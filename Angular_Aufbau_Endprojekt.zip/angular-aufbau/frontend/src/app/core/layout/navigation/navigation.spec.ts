/*
 * navigation.spec.ts – zustandsabhängige Navigation testen
 *
 * Der Test verwendet den echten AuthStore. Den Login-Zustand setzt er mit
 * patchState(unprotected(store), …) – unprotected() aus @ngrx/signals/testing
 * erlaubt das von außen, nur in Tests. Der AuthService wird nicht gebraucht
 * und durch eine leere Attrappe ersetzt.
 *
 * → Aufbau-Handbuch „Den Store verwenden: Navigation und Guards“ (Guards, Navigation und Store testen)
 */
import { TestBed } from '@angular/core/testing';
import { provideRouter, Router } from '@angular/router';
import { patchState } from '@ngrx/signals';
import { unprotected } from '@ngrx/signals/testing';
import { MockProvider } from 'ng-mocks';
import { AuthStore } from '@features/auth';
import { AuthService } from '@features/auth/data-access/auth-service';
import { Navigation } from './navigation';

describe('Navigation', () => {
  async function setup() {
    TestBed.configureTestingModule({
      imports: [Navigation],
      providers: [provideRouter([]), MockProvider(AuthService)],
    });
    const fixture = TestBed.createComponent(Navigation);
    await fixture.whenStable();
    return { fixture, store: TestBed.inject(AuthStore), el: fixture.nativeElement as HTMLElement };
  }

  afterEach(() => sessionStorage.clear());

  it('zeigt ohne Anmeldung „Anmelden“, aber keinen Menüpunkt „Kunden“', async () => {
    const { el } = await setup();
    expect(el.textContent).toContain('Anmelden');
    expect(el.textContent).not.toContain('Kunden');
  });

  it('zeigt nach der Anmeldung Name, „Kunden“ und „Abmelden“', async () => {
    const { fixture, store, el } = await setup();
    patchState(unprotected(store), { user: { id: 2, username: 'ben', name: 'Ben Berater', role: 'user' } });
    await fixture.whenStable();
    expect(el.querySelector('[data-testid="current-user"]')?.textContent).toContain('Ben Berater');
    expect(el.textContent).toContain('Kunden');

    // Abmelden: Zustand zurück und Weiterleitung zur Anmeldeseite (im AuthStore)
    const navigate = vi.spyOn(TestBed.inject(Router), 'navigate').mockResolvedValue(true);
    [...el.querySelectorAll('button')].find((b) => b.textContent?.includes('Abmelden'))!.click();
    expect(store.isLoggedIn()).toBe(false);
    expect(navigate).toHaveBeenCalledWith(['/login']);
  });
});
