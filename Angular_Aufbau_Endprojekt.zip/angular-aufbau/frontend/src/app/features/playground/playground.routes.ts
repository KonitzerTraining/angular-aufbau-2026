/*
 * Routen der Übungsseiten aus dem Grundlagenkurs (Template-Syntax, Signals)
 *
 * Die Seiten gehören nicht zum Fachkern des CRM. Als eigenes Feature
 * „playground“ liegen sie getrennt vom Rest und werden nur geladen, wenn
 * jemand sie aufruft: /playground/template-syntax, /playground/signals.
 *
 * loadComponent lädt jede Seite zusätzlich einzeln nach – wer nur die
 * Template-Syntax öffnet, lädt den Code der Signals-Seite nicht.
 *
 * → Aufbau-Handbuch „Standalone-Feature-Architektur“ (Lazy Loading)
 */
import { Routes } from '@angular/router';

export const playgroundRoutes: Routes = [
  { path: '', redirectTo: 'template-syntax', pathMatch: 'full' },
  {
    path: 'template-syntax',
    title: 'CRM – Template-Syntax',
    loadComponent: () => import('./template-syntax/template-syntax').then((m) => m.TemplateSyntax),
  },
  {
    path: 'signals',
    title: 'CRM – Signals',
    loadComponent: () => import('./signals/signals').then((m) => m.Signals),
  },
];
