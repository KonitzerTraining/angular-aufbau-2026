import { Component } from '@angular/core';
import { CurrencyPipe, DatePipe, DecimalPipe, LowerCasePipe, NgClass, NgStyle, UpperCasePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ValueList } from '@shared/ui/value-list/value-list';
import { InfoCard } from '@shared/ui/info-card/info-card';
import { LoadingIndicator } from '@shared/ui/loading-indicator/loading-indicator';
import { Highlight } from '@shared/directives/highlight';
import { TaxPipe } from '@shared/pipes/tax-pipe';

/**
 * Demoseite für die Template-Syntax
 *
 * Rolle: Seite (Routen-Komponente) für /playground/template-syntax (Feature playground), per loadComponent
 * nachgeladen. Sie ist eine "Spielwiese": Jeder Abschnitt im Template zeigt
 * eine Art der Datenbindung, Control Flow, Pipes oder Content Projection.
 *
 * Hinweis: Die Felder sind hier bewusst normale Klassenfelder (keine Signals).
 * Das genügt, weil sie nur in Event-Handlern wie (click) geändert werden – danach
 * aktualisiert Angular die Anzeige auch ohne Zone.js.
 * → Handbuch 7.6 „Zoneless: warum normale Felder nicht reichen“
 *
 * → Handbuch 6.1 „Die vier Arten der Datenbindung“
 * → Handbuch 6.8 „Control Flow: Bedingungen und Schleifen“
 * → Handbuch 6.9 „Pipes: Werte formatieren“
 */
@Component({
  selector: 'app-template-syntax',
  // Alles, was das Template nutzt, muss importiert werden: Pipes, Direktiven,
  // FormsModule (für ngModel) und die eigenen Kind-Komponenten.
  // → Handbuch 5.4 „Komponenten einbinden“
  imports: [
    CurrencyPipe, DatePipe, DecimalPipe, LowerCasePipe, UpperCasePipe,
    NgClass, NgStyle, FormsModule, ValueList, Highlight, TaxPipe, InfoCard, LoadingIndicator,
  ],
  templateUrl: './template-syntax.html',
})
export class TemplateSyntax {
  // Werte für Interpolation und Pipes → Handbuch 6.2 „Interpolation“
  numValue = 23004.6; // implizit typisiert (number) und implizit public
  strValue = 'Das ist ein Text';
  date = new Date();

  // Werte für Property Binding → Handbuch 6.3 „Property Binding“
  fieldId = 'lastname';
  fieldType = 'text';
  fieldDisabled = true;

  // Angular bereinigt [innerHTML] automatisch (z. B. <script> wird entfernt)
  htmlSnippet = 'Das ist ein <strong>HTML</strong>-Baustein.';
  // Werte für Style- und Klassen-Binding → Handbuch 6.4 „Styles und Klassen binden“
  fgColor = 'white';
  flag = false;

  // Union-Type: status kann nur einen dieser drei Werte annehmen (für das switch-Beispiel)
  status: 'aktiv' | 'gesperrt' | 'neu' = 'aktiv';
  items = ['A', 'B', 'C'];
  // per [(ngModel)] mit dem Eingabefeld verbunden → Handbuch 6.7 „Two-Way-Binding mit ngModel“
  firstname = 'Tom';

  // Event-Handler → Handbuch 6.5 „Auf Ereignisse reagieren“
  changeColor(color: string) {
    this.fgColor = color;
  }

  toggle() {
    this.flag = !this.flag;
  }
}
