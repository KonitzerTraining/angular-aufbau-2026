import { Component, computed, effect, inject, signal } from '@angular/core';
import { JsonPipe } from '@angular/common';
import { toSignal } from '@angular/core/rxjs-interop';
// Import über die öffentliche Schnittstelle (index.ts) des Kunden-Features –
// nie direkt aus dessen Unterordnern. → Aufbau-Handbuch „Standalone-Feature-Architektur“
import { Customer, CustomerService, CustomerTable } from '@features/customers';

/**
 * Demoseite für Signals
 *
 * Rolle: Seite (Routen-Komponente) für /playground/signals (Feature playground), per loadComponent nachgeladen.
 * Sie zeigt die Grundbausteine signal(), computed() und effect(), das
 * unveränderliche Ändern eines Objekts und toSignal() für Serverdaten.
 *
 * → Handbuch 7.2 „signal(): Zustand anlegen, lesen und ändern“
 * → Handbuch 7.3 „computed(): abgeleitete Werte“
 * → Handbuch 7.4 „Objekte und Arrays unveränderlich ändern“
 * → Handbuch 7.5 „effect(): auf Änderungen reagieren“
 * → Handbuch 9.12 „Observables in Signals umwandeln“
 */
@Component({
  selector: 'app-signals',
  // CustomerTable aus dem Kundenbereich wird hier wiederverwendet
  imports: [JsonPipe, CustomerTable],
  templateUrl: './signals.html',
})
export class Signals {
  /** einfacher Zustand */
  // signal(0): ein Behälter mit Startwert 0. Lesen: count(), ändern: set()/update()
  readonly count = signal(0);
  /** abgeleiteter Wert */
  // computed() merkt sich, welche Signals es liest (hier count), und rechnet nur
  // neu, wenn sich eines davon ändert. Es ist schreibgeschützt (kein set()).
  readonly double = computed(() => this.count() * 2);

  /** Objekt als Signal */
  readonly customer = signal<Customer>({ id: 3, name: 'Peter', credit_limit: 200 });

  /** Observable aus dem Service als Signal */
  // toSignal() abonniert das Observable und legt jede Antwort im Signal ab.
  // initialValue: [] gilt, bis der Server geantwortet hat. Das Abo endet
  // automatisch, wenn die Komponente zerstört wird.
  // inject() funktioniert hier, weil Feld-Initialisierer im Injection Context laufen.
  // → Handbuch 9.12 „Observables in Signals umwandeln“, → Handbuch 5.6 „Dependency Injection und inject()“
  readonly customers = toSignal(inject(CustomerService).getAll(), { initialValue: [] });

  constructor() {
    // effect() läuft einmal sofort und danach bei jeder Änderung der gelesenen
    // Signals – geeignet für Nebenwirkungen wie Logging, nicht zum Berechnen von Werten.
    // effect() muss im Konstruktor (Injection Context) angelegt werden.
    effect(() => console.log('count hat sich geändert:', this.count()));
  }

  increment() {
    // update(): neuer Wert aus dem alten berechnet
    this.count.update((value) => value + 1);
  }

  reset() {
    // set(): neuer Wert direkt gesetzt
    this.count.set(0);
  }

  raiseLimit() {
    // Unveränderlich ändern: ein NEUES Objekt mit Spread-Operator erzeugen.
    // Würde man c.credit_limit direkt ändern, bliebe die Referenz gleich und
    // das Signal bemerkte keine Änderung. → Handbuch 7.4 „Objekte und Arrays unveränderlich ändern“
    this.customer.update((c) => ({ ...c, credit_limit: c.credit_limit + 100 }));
  }
}
