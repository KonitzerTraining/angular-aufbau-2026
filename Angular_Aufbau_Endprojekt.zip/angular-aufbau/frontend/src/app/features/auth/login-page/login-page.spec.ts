/*
 * login-page.spec.ts – Reactive Form und AuthStore im Zusammenspiel testen
 *
 * Der Test verwendet den echten AuthStore und ersetzt nur den AuthService
 * darunter. Bedient wird die Seite über das DOM: Text eintippen, absenden,
 * Ergebnis ansehen – so, wie es auch ein Mensch tun würde.
 *
 * → Aufbau-Handbuch „Anmeldung mit dem SignalStore“ (Die Login-Seite testen)
 */
import { TestBed } from '@angular/core/testing';
import { provideRouter, Router } from '@angular/router';
import { MockProvider } from 'ng-mocks';
import { of, throwError } from 'rxjs';
import { LoginPage } from './login-page';
import { AuthService } from '../data-access/auth-service';
import { AuthStore } from '../data-access/auth-store';
import { ADMIN } from '../testing/auth-test-data';

describe('LoginPage', () => {
  // der AuthStore merkt sich die Anmeldung – vor dem nächsten Test löschen
  afterEach(() => sessionStorage.clear());

  async function setup(login: AuthService['login'] = () => of(ADMIN)) {
    const loginSpy = vi.fn<AuthService['login']>(login);
    TestBed.configureTestingModule({
      imports: [LoginPage],
      providers: [provideRouter([]), MockProvider(AuthService, { login: loginSpy })],
    });
    // der AuthStore leitet nach Login und Logout weiter – im Test nur aufzeichnen
    const navigate = vi.spyOn(TestBed.inject(Router), 'navigate').mockResolvedValue(true);
    const fixture = TestBed.createComponent(LoginPage);
    await fixture.whenStable();
    const el = fixture.nativeElement as HTMLElement;

    /** Wert in ein Feld schreiben, wie beim Tippen */
    function type(id: string, value: string) {
      const input = el.querySelector<HTMLInputElement>('#' + id)!;
      input.value = value;
      input.dispatchEvent(new Event('input'));
    }
    async function submit() {
      el.querySelector<HTMLButtonElement>('button[type="submit"]')!.click();
      await fixture.whenStable();
    }
    return { fixture, el, loginSpy, navigate, type, submit, store: TestBed.inject(AuthStore) };
  }

  it('meldet bei leerem Formular nicht an und zeigt beide Fehlermeldungen', async () => {
    const { el, loginSpy, submit } = await setup();
    await submit();
    expect(loginSpy).not.toHaveBeenCalled();
    expect(el.textContent).toContain('Bitte den Benutzernamen eingeben.');
    expect(el.textContent).toContain('Bitte das Kennwort eingeben.');
  });

  it('meldet mit den eingegebenen Zugangsdaten an und führt zur Kundenliste', async () => {
    const { el, loginSpy, navigate, type, submit, store } = await setup();
    type('username', 'anna');
    type('password', 'geheim');
    await submit();
    expect(loginSpy).toHaveBeenCalledWith({ username: 'anna', password: 'geheim' });
    expect(store.user()).toEqual(ADMIN);
    expect(el.textContent).toContain('Anna Admin');
    expect(navigate).toHaveBeenCalledWith(['/customers']);
  });

  it('zeigt die Fehlermeldung aus dem Store', async () => {
    const { el, type, submit } = await setup(() =>
      throwError(() => new Error('Benutzername oder Kennwort ist falsch.')),
    );
    type('username', 'anna');
    type('password', 'falsch');
    await submit();
    expect(el.querySelector('[role="alert"]')?.textContent).toContain('falsch');
  });

  it('meldet ab und zeigt wieder ein leeres Formular', async () => {
    const { fixture, el, type, submit, store } = await setup();
    type('username', 'anna');
    type('password', 'geheim');
    await submit();
    el.querySelector<HTMLButtonElement>('button.btn-secondary')!.click();
    await fixture.whenStable();
    expect(store.isLoggedIn()).toBe(false);
    expect(el.querySelector<HTMLInputElement>('#username')!.value).toBe('');
  });
});
