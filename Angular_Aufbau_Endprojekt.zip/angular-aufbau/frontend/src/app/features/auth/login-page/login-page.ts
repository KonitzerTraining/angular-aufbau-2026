import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthStore } from '../data-access/auth-store';

/**
 * Anmeldeseite
 *
 * Rolle: Smart Component für /login. Sie kennt weder AuthService noch HTTP –
 * sie spricht nur mit dem AuthStore:
 *   - schreiben: authStore.login(credentials), authStore.logout()
 *   - lesen:     authStore.loading(), authStore.error(), authStore.user()
 *
 * Das Formular ist ein Reactive Form mit dem FormBuilder – so wie im
 * Startprojekt, nur dass es jetzt wirklich anmeldet. Signal Forms verwendet
 * das CRM für das Kundenformular.
 *
 * Nach erfolgreicher Anmeldung leitet der AuthStore zur Kundenliste weiter.
 *
 * Ablage: features/auth – eigenes Feature, per loadChildren unter /login nachgeladen.
 *
 * → Aufbau-Handbuch „Anmeldung mit dem SignalStore“ (Das Login-Formular)
 */
@Component({
  selector: 'app-login-page',
  imports: [ReactiveFormsModule],
  templateUrl: './login-page.html',
})
export class LoginPage {
  protected readonly authStore = inject(AuthStore);

  // nonNullable: getRawValue() liefert string statt string | null,
  // und reset() setzt auf '' statt auf null zurück
  protected readonly form = inject(FormBuilder).nonNullable.group({
    username: ['', Validators.required],
    password: ['', Validators.required],
  });

  submitHandler(): void {
    if (this.form.invalid) {
      // alle Felder als berührt markieren, damit die Fehlermeldungen erscheinen
      this.form.markAllAsTouched();
      return;
    }
    // getRawValue(): { username, password } – passt genau auf Credentials
    this.authStore.login(this.form.getRawValue());
  }

  logout(): void {
    this.authStore.logout();
    // Formular leeren: Werte zurück auf '' und Zustand „unberührt“
    this.form.reset();
  }
}
