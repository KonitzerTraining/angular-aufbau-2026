/*
 * auth.guards.spec.ts – funktionale Guards testen
 *
 * Ein funktionaler Guard braucht einen Injection Context (wegen inject()).
 * TestBed.runInInjectionContext() stellt ihn bereit. Den Zustand setzen wir
 * im echten AuthStore: unprotected() aus @ngrx/signals/testing erlaubt
 * patchState() von außen – nur in Tests gedacht.
 *
 * → Aufbau-Handbuch „Den Store verwenden: Navigation und Guards“ (Guards testen)
 */
import { TestBed } from '@angular/core/testing';
import { ActivatedRouteSnapshot, provideRouter, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { patchState } from '@ngrx/signals';
import { unprotected } from '@ngrx/signals/testing';
import { adminGuard, authGuard } from './auth.guards';
import { AuthStore } from './data-access/auth-store';
import { User } from './model/user';
import { ADMIN, USER } from './testing/auth-test-data';

describe('Guards', () => {
  function run(user: User | null, guard: typeof authGuard, url = '/customers') {
    TestBed.configureTestingModule({ providers: [provideRouter([])] });
    patchState(unprotected(TestBed.inject(AuthStore)), { user });
    const route = {} as ActivatedRouteSnapshot;
    const state = { url } as RouterStateSnapshot;
    return TestBed.runInInjectionContext(() => guard(route, state));
  }

  afterEach(() => sessionStorage.clear());

  it('authGuard lässt angemeldete Personen durch', () => {
    expect(run(USER, authGuard)).toBe(true);
  });

  it('authGuard leitet sonst zur Anmeldung um', () => {
    const result = run(null, authGuard, '/customers/edit/3');
    expect(result).toBeInstanceOf(UrlTree);
    // UrlTree in Text umwandeln: Router.serializeUrl
    expect(TestBed.inject(Router).serializeUrl(result as UrlTree)).toBe('/login');
  });

  it('adminGuard lässt nur Admins durch', () => {
    expect(run(ADMIN, adminGuard)).toBe(true);
    TestBed.resetTestingModule();
    const result = run(USER, adminGuard);
    expect(TestBed.inject(Router).serializeUrl(result as UrlTree)).toBe('/customers');
  });
});
