/*
 * auth-service.ts – Anmeldung gegen das Mock-Backend
 *
 * ACHTUNG, nur für die Schulung: json-server kennt keine echte Anmeldung.
 * Der Service fragt GET /users?username=…&password=… ab und nimmt den ersten
 * Treffer. In einem echten Projekt schickt man die Zugangsdaten per POST an
 * einen Auth-Server (z. B. OAuth2/OpenID Connect) und bekommt ein Token
 * zurück – Kennwörter gehören nie in eine URL und nie ins Frontend.
 *
 * Wichtig für den Rest der Anwendung ist nur die Schnittstelle:
 * login(credentials) liefert ein Observable<User> oder einen Fehler. Wer
 * später auf einen echten Auth-Server umstellt, ändert nur diese Datei.
 *
 * → Aufbau-Handbuch „Anmeldung mit dem SignalStore“
 */
import { inject, Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { environment } from '@env/environment';
import { Credentials, User } from '../model/user';

/** So liefert json-server einen Benutzer – inklusive Kennwort */
interface UserRecord extends User {
  password: string;
}

export const USERS_URL = environment.api + 'users';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);

  login(credentials: Credentials): Observable<User> {
    // HttpParams baut die Query-Parameter sauber kodiert: ?username=anna&password=…
    const params = new HttpParams().set('username', credentials.username).set('password', credentials.password);
    return this.http.get<UserRecord[]>(USERS_URL, { params }).pipe(
      map((users) => {
        const record = users[0];
        if (!record) {
          // ein Fehler im map() wird zum Fehler des Observables → der AuthStore speichert die Meldung in error
          throw new Error('Benutzername oder Kennwort ist falsch.');
        }
        // Kennwort nicht weiterreichen: Destrukturierung mit Rest-Operator
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { password, ...user } = record;
        return user;
      }),
    );
  }
}
