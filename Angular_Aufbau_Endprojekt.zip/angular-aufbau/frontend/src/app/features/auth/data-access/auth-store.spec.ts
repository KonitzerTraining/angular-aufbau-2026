/*
 * auth-store.spec.ts – den AuthStore testen
 *
 * Ein SignalStore ist ein Service: TestBed.inject() liefert ihn, der
 * AuthService darunter wird durch eine Attrappe ersetzt. Geprüft wird nur
 * von außen: Methode aufrufen, Signals lesen. Dazu kommen
 * Weiterleitung über den Router und Sitzung im sessionStorage.
 *
 * → Aufbau-Handbuch „Anmeldung mit dem SignalStore“ (Den AuthStore testen)
 * → Aufbau-Handbuch „Den Store verwenden: Navigation und Guards“
 */
import { TestBed } from '@angular/core/testing';
import { provideRouter, Router } from '@angular/router';
import { MockProvider } from 'ng-mocks';
import { of, throwError } from 'rxjs';
import { AuthStore } from './auth-store';
import { AuthService } from './auth-service';
import { ADMIN, CREDENTIALS, USER } from '../testing/auth-test-data';

describe('AuthStore', () => {
  function setup(login: AuthService['login'] = () => of(ADMIN)) {
    const loginSpy = vi.fn<AuthService['login']>(login);
    TestBed.configureTestingModule({
      providers: [provideRouter([]), MockProvider(AuthService, { login: loginSpy })],
    });
    // nicht wirklich navigieren, nur aufzeichnen
    const router = TestBed.inject(Router);
    const navigate = vi.spyOn(router, 'navigate').mockResolvedValue(true);
    return { store: TestBed.inject(AuthStore), loginSpy, navigate };
  }

  afterEach(() => sessionStorage.clear());

  it('startet abgemeldet', () => {
    const { store } = setup();
    expect(store.user()).toBeNull();
    expect(store.isLoggedIn()).toBe(false);
    expect(store.isAdmin()).toBe(false);
  });

  it('meldet an und berechnet isLoggedIn und isAdmin', () => {
    const { store, loginSpy } = setup();
    store.login(CREDENTIALS);
    expect(loginSpy).toHaveBeenCalledWith(CREDENTIALS);
    expect(store.user()).toEqual(ADMIN);
    expect(store.isLoggedIn()).toBe(true);
    expect(store.isAdmin()).toBe(true);
    expect(store.loading()).toBe(false);
  });

  it('isAdmin ist false für normale Benutzer', () => {
    const { store } = setup(() => of(USER));
    store.login(CREDENTIALS);
    expect(store.isLoggedIn()).toBe(true);
    expect(store.isAdmin()).toBe(false);
  });

  it('speichert die Fehlermeldung, wenn die Anmeldung scheitert', () => {
    const { store, navigate } = setup(() => throwError(() => new Error('Benutzername oder Kennwort ist falsch.')));
    store.login(CREDENTIALS);
    expect(store.user()).toBeNull();
    expect(store.error()).toBe('Benutzername oder Kennwort ist falsch.');
    expect(navigate).not.toHaveBeenCalled();
  });

  it('leitet nach der Anmeldung zur Kundenliste weiter', () => {
    const { store, navigate } = setup();
    store.login(CREDENTIALS);
    expect(navigate).toHaveBeenCalledWith(['/customers']);
  });

  it('logout setzt den Zustand zurück und führt zur Anmeldeseite', () => {
    const { store, navigate } = setup();
    store.login(CREDENTIALS);
    store.logout();
    expect(store.isLoggedIn()).toBe(false);
    expect(navigate).toHaveBeenCalledWith(['/login']);
  });

  it('merkt sich die Anmeldung im sessionStorage und löscht sie beim Abmelden', () => {
    const { store } = setup();
    store.login(CREDENTIALS);
    expect(JSON.parse(sessionStorage.getItem('crm.user')!)).toEqual(ADMIN);
    store.logout();
    expect(sessionStorage.getItem('crm.user')).toBeNull();
  });

  it('startet angemeldet, wenn eine Sitzung gespeichert ist', () => {
    sessionStorage.setItem('crm.user', JSON.stringify(USER));
    const { store } = setup();
    expect(store.user()).toEqual(USER);
  });
});
