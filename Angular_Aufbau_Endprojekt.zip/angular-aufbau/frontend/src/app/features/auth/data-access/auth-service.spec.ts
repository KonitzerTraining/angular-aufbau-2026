/*
 * auth-service.spec.ts – Anmeldung gegen das Mock-Backend testen
 * → Aufbau-Handbuch „Anmeldung mit dem SignalStore“, „Unit-Tests mit Vitest“
 */
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { AuthService, USERS_URL } from './auth-service';
import { ADMIN, CREDENTIALS } from '../testing/auth-test-data';

describe('AuthService', () => {
  let service: AuthService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    service = TestBed.inject(AuthService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('liefert den Benutzer ohne Kennwort', () => {
    const next = vi.fn();
    service.login(CREDENTIALS).subscribe(next);
    // expectOne mit Funktion: prüft URL und Query-Parameter
    const request = http.expectOne((r) => r.url === USERS_URL && r.params.get('username') === 'anna');
    request.flush([{ ...ADMIN, password: 'geheim' }]);
    expect(next).toHaveBeenCalledWith(ADMIN);
    expect(next.mock.calls[0][0]).not.toHaveProperty('password');
  });

  it('meldet einen Fehler, wenn kein Benutzer passt', () => {
    const error = vi.fn();
    service.login(CREDENTIALS).subscribe({ error });
    http.expectOne((r) => r.url === USERS_URL).flush([]);
    expect(error.mock.calls[0][0].message).toContain('falsch');
  });
});
