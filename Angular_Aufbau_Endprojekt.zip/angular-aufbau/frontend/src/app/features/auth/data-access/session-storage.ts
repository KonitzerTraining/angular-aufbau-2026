/*
 * session-storage.ts – Anmeldung über ein Neuladen der Seite hinweg behalten
 *
 * Der AuthStore lebt im Arbeitsspeicher: F5 = leerer Store = abgemeldet.
 * Deshalb legen wir den angemeldeten Benutzer zusätzlich im sessionStorage
 * des Browsers ab (gilt nur für diesen Tab und endet mit dem Schließen).
 *
 *   - Schreiben/Löschen: watchState in withHooks (auth-store.ts)
 *   - Lesen beim Start:  withState(() => …) (auth-store.ts)
 *
 * In einem echten Projekt speichert man hier ein Token des Auth-Servers,
 * nicht die Benutzerdaten – und prüft es beim Start gegen den Server.
 *
 * → Aufbau-Handbuch „Den Store verwenden: Navigation und Guards“
 */
import { User } from '../model/user';

const KEY = 'crm.user';

export function readStoredUser(): User | null {
  try {
    const json = sessionStorage.getItem(KEY);
    return json ? (JSON.parse(json) as User) : null;
  } catch {
    // z. B. gesperrter Speicher oder kaputter Inhalt: dann eben nicht angemeldet
    return null;
  }
}

export function storeUser(user: User | null): void {
  try {
    if (user) {
      sessionStorage.setItem(KEY, JSON.stringify(user));
    } else {
      sessionStorage.removeItem(KEY);
    }
  } catch {
    // Speichern ist ein Komfort – scheitert es, läuft die Anwendung trotzdem
  }
}
