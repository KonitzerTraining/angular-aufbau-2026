/*
 * auth-store.ts – Anmeldezustand mit dem NgRx SignalStore
 *
 * In der Fassung mit Angular 21 (Branch main) übernimmt Classic NgRx diese
 * Aufgabe: Actions, Reducer, Selektoren und Effects in vier Dateien. Der
 * SignalStore braucht dafür eine Datei – derselbe Zustand, dieselben
 * abgeleiteten Werte, aber Methoden statt Actions:
 *
 *   Classic NgRx                         SignalStore
 *   store.dispatch(AuthActions.login())  authStore.login(credentials)
 *   authFeature.selectUser               authStore.user()
 *   selectIsLoggedIn (createSelector)    isLoggedIn (withComputed)
 *   Effect login (HTTP)                  rxMethod login
 *   Reducer on(logout)                   logout() mit patchState
 *   Effects redirectAfterLogin/-Logout   Router-Aufruf direkt in login()/logout()
 *   Effect persistSession                withHooks + watchState
 *
 * → Aufbau-Handbuch „Anmeldung mit dem SignalStore“
 * → Aufbau-Handbuch „Den Store verwenden: Navigation und Guards“ (Weiterleiten, Sitzung behalten)
 */
import { computed, inject } from '@angular/core';
import { Router } from '@angular/router';
import { patchState, signalStore, watchState, withComputed, withHooks, withMethods, withState } from '@ngrx/signals';
import { rxMethod } from '@ngrx/signals/rxjs-interop';
import { tapResponse } from '@ngrx/operators';
import { exhaustMap, pipe, tap } from 'rxjs';
import { AuthService } from './auth-service';
import { readStoredUser, storeUser } from './session-storage';
import { Credentials, User } from '../model/user';

/** Form des Zustands – nur Daten, keine Logik */
export interface AuthState {
  /** angemeldete Person oder null */
  user: User | null;
  /** true, solange die Anmeldung läuft */
  loading: boolean;
  /** Fehlermeldung der letzten Anmeldung */
  error: string | null;
}

export const initialAuthState: AuthState = {
  user: null,
  loading: false,
  error: null,
};

export const AuthStore = signalStore(
  // eine Instanz für die ganze Anwendung: Navigation, Guards und Login-Seite
  // sehen denselben Zustand
  { providedIn: 'root' },
  // authStore.user(), authStore.loading(), authStore.error()
  // Als Funktion: Der Startzustand liest einmal die gespeicherte
  // Anmeldung aus dem sessionStorage – so übersteht sie ein Neuladen (F5).
  withState(() => ({ ...initialAuthState, user: readStoredUser() })),
  // abgeleitete Werte – entsprechen den extraSelectors in Classic NgRx
  withComputed(({ user }) => ({
    isLoggedIn: computed(() => user() !== null),
    isAdmin: computed(() => user()?.role === 'admin'),
  })),
  withMethods((store, authService = inject(AuthService), router = inject(Router)) => ({
    /**
     * Anmelden. exhaustMap: Ein Doppelklick auf „Anmelden“ zählt nur einmal,
     * solange die erste Anfrage läuft.
     * tapResponse behandelt Erfolg und Fehler der einzelnen Anfrage; die
     * Pipeline bleibt nach einem Fehler nutzbar (zweiter Versuch klappt).
     *
     * Nach dem Erfolg navigiert login() selbst zur Kundenliste. In Classic
     * NgRx übernimmt das der Effect redirectAfterLogin; im SignalStore gehört
     * es in die Methode.
     */
    login: rxMethod<Credentials>(
      pipe(
        tap(() => patchState(store, { loading: true, error: null })),
        exhaustMap((credentials) =>
          authService.login(credentials).pipe(
            tapResponse({
              next: (user) => {
                patchState(store, { user, loading: false });
                router.navigate(['/customers']);
              },
              error: (e: Error) => patchState(store, { error: e.message, loading: false }),
            }),
          ),
        ),
      ),
    ),

    /** Abmelden: zurück zum Startzustand und zur Anmeldeseite */
    logout(): void {
      patchState(store, initialAuthState);
      router.navigate(['/login']);
    },
  })),
  // withHooks: Code beim Erzeugen des Stores
  withHooks({
    onInit(store) {
      // watchState ruft die Funktion bei jeder Zustandsänderung auf und hält
      // so den sessionStorage aktuell: angemeldet → speichern, abgemeldet → löschen.
      // Das entspricht dem Effect persistSession in Classic NgRx.
      watchState(store, (state) => storeUser(state.user));
    },
  }),
);
