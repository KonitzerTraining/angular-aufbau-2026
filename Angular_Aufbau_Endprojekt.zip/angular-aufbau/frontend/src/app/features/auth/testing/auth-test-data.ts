/*
 * Testdaten für das Auth-Feature
 * → Aufbau-Handbuch „Unit-Tests mit Vitest“ (Stufe 1: Testdaten auslagern)
 */
import { Credentials, User } from '../model/user';

export const ADMIN: User = { id: 1, username: 'anna', name: 'Anna Admin', role: 'admin' };
export const USER: User = { id: 2, username: 'ben', name: 'Ben Berater', role: 'user' };
export const CREDENTIALS: Credentials = { username: 'anna', password: 'geheim' };
