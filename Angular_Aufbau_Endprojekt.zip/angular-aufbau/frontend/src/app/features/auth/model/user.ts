/*
 * user.ts – Datenmodell für die Anmeldung
 *
 * Ablage: features/auth/model – nur Interfaces und Typen, ohne Abhängigkeiten.
 * Service, Store und Komponenten importieren von hier, nie umgekehrt.
 *
 * → Aufbau-Handbuch „Anmeldung mit dem SignalStore“
 */

/** Rollen im CRM – steuern, welche Funktionen sichtbar sind */
export type Role = 'admin' | 'user';

/** Angemeldete Person, wie sie im Store liegt (ohne Kennwort!) */
export interface User {
  id: number;
  username: string;
  name: string;
  role: Role;
}

/** Eingaben aus dem Anmeldeformular */
export interface Credentials {
  username: string;
  password: string;
}
