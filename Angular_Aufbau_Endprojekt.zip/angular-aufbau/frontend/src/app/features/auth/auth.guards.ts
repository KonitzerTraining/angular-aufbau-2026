/*
 * auth.guards.ts – Routen absichern mit funktionalen Guards
 *
 * Ein Guard entscheidet, ob eine Route betreten werden darf. Funktionale
 * Guards sind einfache Funktionen (statt Klassen mit canActivate()); per
 * inject() holen sie sich, was sie brauchen – hier den AuthStore.
 *
 * Rückgabewerte:
 *   true       → Route betreten
 *   UrlTree    → stattdessen dorthin umleiten (hier: /login)
 *
 * Verwendet in app.routes.ts (authGuard für /customers) und
 * customers.routes.ts (adminGuard für /customers/new).
 *
 * WICHTIG: Guards schützen nur die Oberfläche. Ein Angreifer kann jede
 * Anfrage auch ohne Angular an den Server schicken – die eigentliche
 * Berechtigungsprüfung muss immer das Backend machen.
 *
 * → Aufbau-Handbuch „Den Store verwenden: Navigation und Guards“ (Routen absichern mit funktionalen Guards)
 */
import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthStore } from './data-access/auth-store';

/** nur für angemeldete Personen */
export const authGuard: CanActivateFn = () => {
  // isLoggedIn ist ein Signal – aufrufen liefert den aktuellen Wert
  if (inject(AuthStore).isLoggedIn()) {
    return true;
  }
  // nicht angemeldet: zur Anmeldeseite; nach dem Login führt der AuthStore zur Kundenliste
  return inject(Router).createUrlTree(['/login']);
};

/** nur für Admins – alle anderen landen auf der Kundenliste */
export const adminGuard: CanActivateFn = () => {
  return inject(AuthStore).isAdmin() || inject(Router).createUrlTree(['/customers']);
};
