/*
 * Routen des Auth-Features
 *
 * Wird in app.routes.ts per loadChildren nachgeladen. Die Anmeldeseite landet
 * dadurch in einem eigenen JavaScript-Chunk und belastet den Start der
 * Anwendung nicht.
 *
 * → Aufbau-Handbuch „Standalone-Feature-Architektur“ (Feature-based Routing)
 */
import { Routes } from '@angular/router';
import { LoginPage } from './login-page/login-page';

export const authRoutes: Routes = [
  // '' ist hier relativ zum Pfad in app.routes.ts – ergibt also /login
  { path: '', component: LoginPage, title: 'CRM – Anmelden' },
];
