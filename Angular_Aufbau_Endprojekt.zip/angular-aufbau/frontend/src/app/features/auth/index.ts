/*
 * Öffentliche Schnittstelle des Auth-Features
 *
 * Wer den Login-Zustand braucht (die Navigation in core/ und die Guards in
 * app.routes.ts und customers.routes.ts), importiert von '@features/auth' –
 * nicht aus model/ oder data-access/.
 *
 * → Aufbau-Handbuch „Standalone-Feature-Architektur“, „Anmeldung mit dem SignalStore“
 */
export type { User, Role, Credentials } from './model/user';
export { AuthStore } from './data-access/auth-store';
// Guards für andere Features und app.routes.ts
export { authGuard, adminGuard } from './auth.guards';
