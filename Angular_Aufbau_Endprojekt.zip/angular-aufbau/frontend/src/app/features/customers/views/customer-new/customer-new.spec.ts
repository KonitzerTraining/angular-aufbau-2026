/*
 * customer-new.spec.ts – Smart Component mit Service und Router testen
 *
 * Zwei Abhängigkeiten werden ersetzt bzw. beobachtet:
 *   - CustomerService → ng-mocks-Attrappe, postOne() antwortet sofort
 *   - Router → echter Test-Router, aber navigate() als Spy (vi.spyOn), damit
 *     wir prüfen können, WOHIN navigiert wird, ohne wirklich zu navigieren
 *
 * → Aufbau-Handbuch „Unit-Tests mit Vitest“ (Stufe 3: den Service mocken und die Komponente testen)
 */
import { TestBed } from '@angular/core/testing';
import { provideRouter, Router } from '@angular/router';
import { MockProvider } from 'ng-mocks';
import { of, throwError } from 'rxjs';
import { CustomerNew } from './customer-new';
import { CustomerService } from '../../data-access/customer-service';
import { createCustomer } from '../../testing/customer-test-data';

describe('CustomerNew', () => {
  function setup(postResult: ReturnType<CustomerService['postOne']>) {
    const postOne = vi.fn<CustomerService['postOne']>(() => postResult);
    TestBed.configureTestingModule({
      imports: [CustomerNew],
      providers: [provideRouter([]), MockProvider(CustomerService, { postOne })],
    });
    // Spy auf eine echte Methode: navigate() wird beobachtet und durch eine
    // Attrappe ersetzt, die sofort ein erfülltes Promise liefert
    const navigate = vi.spyOn(TestBed.inject(Router), 'navigate').mockResolvedValue(true);
    const fixture = TestBed.createComponent(CustomerNew);
    fixture.detectChanges();
    return { component: fixture.componentInstance, postOne, navigate };
  }

  it('speichert den Kunden und wechselt zur Liste', () => {
    const { component, postOne, navigate } = setup(of(createCustomer({ id: 9 })));
    component.createCustomer({ name: 'Neu', credit_limit: 800 });
    expect(postOne).toHaveBeenCalledWith({ name: 'Neu', credit_limit: 800 });
    expect(navigate).toHaveBeenCalledWith(['/customers']);
  });

  it('bleibt bei einem Fehler auf der Seite und zeigt die Meldung', () => {
    const { component, navigate } = setup(throwError(() => new Error('Validierung fehlgeschlagen')));
    component.createCustomer({ name: 'Neu', credit_limit: 800 });
    expect(navigate).not.toHaveBeenCalled();
    expect(component.errorMessage()).toContain('Validierung fehlgeschlagen');
    expect(component.saving()).toBe(false);
  });
});
