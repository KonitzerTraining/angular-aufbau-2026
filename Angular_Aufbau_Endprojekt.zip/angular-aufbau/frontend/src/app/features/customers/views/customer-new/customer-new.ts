import { Component, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { NewCustomer } from '../../model/customer';
import { CustomerService } from '../../data-access/customer-service';
import { CustomerForm } from '../../ui/customer-form/customer-form';
import { LoadingIndicator } from '@shared/ui/loading-indicator/loading-indicator';
import { MessageBox } from '@shared/ui/message-box/message-box';

/**
 * Neuen Kunden anlegen
 *
 * Rolle: Seite (Route /customers/new) und Smart Component. Sie bindet das
 * wiederverwendbare CustomerForm ein, schickt dessen Daten per POST an den
 * Server und navigiert danach zurück zur Liste.
 *
 * → Handbuch 10.8 „Senden mit dem Service: Neuer Kunde“
 * → Handbuch 10.9 „Programmatisches Routing“
 * → Handbuch 11.7 „Smart und Presentational Components“
 */
@Component({
  selector: 'app-customer-new',
  imports: [RouterLink, CustomerForm, LoadingIndicator, MessageBox],
  templateUrl: './customer-new.html',
})
export class CustomerNew {
  private readonly customerService = inject(CustomerService);
  // Router-Service für die Navigation aus dem Code heraus
  private readonly router = inject(Router);

  // Zustand als Signals (Antwort kommt asynchron)
  readonly saving = signal(false);
  readonly errorMessage = signal<string | null>(null);

  // Wird über (customerSubmit) aus dem CustomerForm aufgerufen
  createCustomer(customer: NewCustomer) {
    this.saving.set(true);
    this.errorMessage.set(null);
    this.customerService.postOne(customer).subscribe({
      // Erfolg: programmatisch zur Liste navigieren (wie ein Klick auf routerLink)
      // → Handbuch 8.7 „Programmatisch navigieren“
      next: () => this.router.navigate(['/customers']),
      error: (e: Error) => {
        this.errorMessage.set('Speichern fehlgeschlagen: ' + e.message);
        // Formular wieder anzeigen, damit man es erneut versuchen kann
        this.saving.set(false);
      },
    });
  }
}
