import { Component, inject, OnInit } from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthStore } from '@features/auth';
import { CustomerStore } from '../../data-access/customer-store';
import { CustomerTable } from '../../ui/customer-table/customer-table';
import { LoadingIndicator } from '@shared/ui/loading-indicator/loading-indicator';
import { MessageBox } from '@shared/ui/message-box/message-box';

/**
 * Kundenliste mit Suchfilter
 *
 * Rolle: Smart Component für die Route /customers.
 *
 * Diese Komponente hält KEINEN eigenen Zustand. Vor dem Umbau auf den Store
 * standen hier customers, loading und errorMessage als Signals, dazu die
 * subscribe()-Logik fürs Laden und Löschen. Jetzt liegt all das im
 * CustomerStore; die Komponente
 *   - liest den Zustand (store.filteredCustomers(), store.loading(), store.error())
 *   - löst Aktionen aus (store.load(), store.remove(id), store.setFilter(text))
 *
 * Damit ist sie deutlich kürzer und fast nur noch „Verdrahtung“ zwischen
 * Store und Template.
 *
 * → Aufbau-Handbuch „NgRx SignalStore“ (Integration mit Komponenten)
 * Grundlagen dazu: → Handbuch 11.7 „Smart und Presentational Components“
 */
@Component({
  selector: 'app-customer-list',
  imports: [RouterLink, CurrencyPipe, CustomerTable, LoadingIndicator, MessageBox],
  templateUrl: './customer-list.html',
})
export class CustomerList implements OnInit {
  // protected: das Template darf darauf zugreifen, andere Klassen nicht
  protected readonly store = inject(CustomerStore);

  // „Neuer Kunde“ nur für Admins. Zwei Stores nebeneinander:
  // CustomerStore für die Kunden, AuthStore für den Login – beide SignalStores.
  // → Aufbau-Handbuch „Den Store verwenden: Navigation und Guards“ (State-abhängige Navigationspunkte)
  protected readonly isAdmin = inject(AuthStore).isAdmin;

  ngOnInit(): void {
    // bei jedem Öffnen der Liste frisch laden – so sind auch Kunden zu sehen,
    // die gerade über „Neu“ oder „Bearbeiten“ gespeichert wurden
    this.store.load();
  }

  /** Eingabe im Suchfeld an den Store weitergeben */
  protected search(event: Event): void {
    this.store.setFilter((event.target as HTMLInputElement).value);
  }
}
