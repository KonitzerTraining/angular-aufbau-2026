/*
 * customer-list.spec.ts – Unit-Test einer Smart Component mit ng-mocks
 *
 * CustomerList holt ihre Daten über den CustomerService und zeigt sie mit
 * Kind-Komponenten an. Im Unit-Test wollen wir NUR die Logik von CustomerList
 * prüfen – nicht den Server, nicht die Tabelle. Deshalb ersetzen wir die
 * Abhängigkeiten durch Attrappen (Mocks):
 *
 *   MockProvider(CustomerService, {...})  – Service-Attrappe mit eigenen Antworten
 *   vi.fn()                               – Spy: merkt sich Aufrufe und Argumente
 *   of(...) / throwError(...)             – Observable, das sofort Daten oder einen Fehler liefert
 *
 * ng-mocks erzeugt Attrappen automatisch aus der echten Klasse: Alle Methoden
 * existieren, tun aber nichts, solange wir ihnen kein Verhalten geben.
 *
 * Der zweite describe-Block ersetzt zusätzlich die Kind-Komponente
 * CustomerTable durch MockComponent(CustomerTable). Dann prüft der Test nur
 * noch die Verbindung: was die Liste an die Tabelle übergibt und wie sie auf
 * deren Ereignisse reagiert.
 *
 * → Aufbau-Handbuch „Unit-Tests mit Vitest“ (Stufe 3: den Service mocken und die Komponente testen)
 * → Aufbau-Handbuch „Unit-Tests mit Vitest“ (Stufe 4: weitere Abhängigkeiten wegmocken)
 *
 * Der Zustand liegt im CustomerStore. Der Test verwendet den
 * echten Store und ersetzt nur den Service darunter – so prüft er Komponente
 * und Store im Zusammenspiel. → Aufbau-Handbuch „NgRx SignalStore“
 */
import { TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { provideRouter } from '@angular/router';
import { MockComponent, MockProvider } from 'ng-mocks';
import { patchState } from '@ngrx/signals';
import { unprotected } from '@ngrx/signals/testing';
import { AuthStore } from '@features/auth';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { Observable, of, throwError } from 'rxjs';
import type { Mock } from 'vitest';
import { CustomerList } from './customer-list';
import { CustomerService } from '../../data-access/customer-service';
import { CustomerStore } from '../../data-access/customer-store';
import { CustomerTable } from '../../ui/customer-table/customer-table';
import { CUSTOMERS } from '../../testing/customer-test-data';

describe('CustomerList', () => {
  // Spies für die beiden Service-Methoden, die CustomerList aufruft
  // Mock<Signatur>: der Spy hat dieselbe Signatur wie die echte Methode –
  // TypeScript prüft so auch die Testattrappe.
  let getAll: Mock<CustomerService['getAll']>;
  let deleteById: Mock<CustomerService['deleteById']>;

  /** Testumgebung aufbauen; jeder Test kann das Verhalten von getAll vorgeben */
  function setup(getAllResult: ReturnType<CustomerService['getAll']> = of([...CUSTOMERS])) {
    getAll = vi.fn<CustomerService['getAll']>(() => getAllResult);
    deleteById = vi.fn<CustomerService['deleteById']>((): Observable<unknown> => of({}));

    TestBed.configureTestingModule({
      imports: [CustomerList],
      providers: [
        provideRouter([]),
        // statt des echten Service (mit HttpClient) eine Attrappe bereitstellen
        MockProvider(CustomerService, { getAll, deleteById }),
        // die Liste fragt den AuthStore, ob Admin. Dessen AuthService braucht
        // einen HttpClient; angefragt wird hier nichts, die Testfassung genügt.
        provideHttpClient(),
        provideHttpClientTesting(),
      ],
    });
    // als Admin angemeldet, damit „Neuer Kunde“ erscheint (unprotected: nur in Tests)
    patchState(unprotected(TestBed.inject(AuthStore)), {
      user: { id: 1, username: 'anna', name: 'Anna', role: 'admin' },
    });
    const fixture = TestBed.createComponent(CustomerList);
    // detectChanges() startet die Darstellung – dabei läuft ngOnInit() und damit loadCustomers()
    fixture.detectChanges();
    return fixture;
  }

  it('lädt beim Start alle Kunden über den Service', () => {
    const fixture = setup();
    // toHaveBeenCalledOnce: genau ein Aufruf – nicht keiner, nicht doppelt
    expect(getAll).toHaveBeenCalledOnce();
    expect(TestBed.inject(CustomerStore).customers()).toHaveLength(3);
    // drei Zeilen in der Tabelle
    expect((fixture.nativeElement as HTMLElement).querySelectorAll('tbody tr')).toHaveLength(3);
  });

  it('zeigt eine Fehlermeldung, wenn das Laden scheitert', () => {
    const fixture = setup(throwError(() => new Error('Server nicht erreichbar')));
    expect(TestBed.inject(CustomerStore).error()).toContain('Server nicht erreichbar');
    // die Meldung steht auch wirklich im DOM (role="alert" aus der MessageBox)
    expect((fixture.nativeElement as HTMLElement).querySelector('[role="alert"]')?.textContent).toContain(
      'Server nicht erreichbar',
    );
  });

  it('löscht einen Kunden über den Service und entfernt ihn aus der Liste', () => {
    setup();
    const store = TestBed.inject(CustomerStore);
    store.remove(2);
    // toHaveBeenCalledWith: prüft die Argumente des Aufrufs
    expect(deleteById).toHaveBeenCalledWith(2);
    expect(store.customers().map((c) => c.id)).toEqual([1, 3]);
  });

  it('lädt neu, wenn „Aktualisieren“ geklickt wird', () => {
    const fixture = setup();
    const button = [...(fixture.nativeElement as HTMLElement).querySelectorAll('button')].find((b) =>
      b.textContent?.includes('Aktualisieren'),
    )!;
    button.click();
    expect(getAll).toHaveBeenCalledTimes(2);
  });

  it('filtert die Tabelle über das Suchfeld', async () => {
    const fixture = setup();
    const input = (fixture.nativeElement as HTMLElement).querySelector<HTMLInputElement>('#search')!;
    // Benutzereingabe simulieren: Wert setzen und input-Ereignis auslösen
    input.value = 'tim';
    input.dispatchEvent(new Event('input'));
    await fixture.whenStable();
    const rows = (fixture.nativeElement as HTMLElement).querySelectorAll('tbody tr');
    expect(rows).toHaveLength(1);
    expect(rows[0].textContent).toContain('Tim');
  });
});

describe('CustomerList mit MockComponent(CustomerTable)', () => {
  function setup(getAllResult: ReturnType<CustomerService['getAll']> = of([...CUSTOMERS])) {
    const deleteById = vi.fn<CustomerService['deleteById']>((): Observable<unknown> => of({}));
    TestBed.configureTestingModule({
      imports: [CustomerList],
      providers: [
        provideRouter([]),
        MockProvider(CustomerService, { getAll: () => getAllResult, deleteById }),
        provideHttpClient(),
        provideHttpClientTesting(),
      ],
    });
    // die echte Tabelle aus den imports der Komponente gegen die Attrappe tauschen –
    // overrideComponent() muss vor createComponent() stehen
    TestBed.overrideComponent(CustomerList, {
      remove: { imports: [CustomerTable] },
      add: { imports: [MockComponent(CustomerTable)] },
    });
    const fixture = TestBed.createComponent(CustomerList);
    fixture.detectChanges();
    // By.directive(CustomerTable) findet auch die Attrappe – ng-mocks legt sie als Ersatz für genau diese Klasse an
    const tableElement = fixture.debugElement.query(By.directive(CustomerTable));
    const table = tableElement?.componentInstance as CustomerTable | undefined;
    return { fixture, table, deleteById };
  }

  it('reicht die Kunden an die Tabelle weiter', () => {
    const { table } = setup();
    expect(table!.data()).toHaveLength(3);
  });

  it('löscht, wenn die Tabelle deleteEvent meldet', () => {
    const { table, deleteById } = setup();
    // die Attrappe meldet das Ereignis wie die echte Tabelle
    table!.deleteEvent.emit(2);
    expect(deleteById).toHaveBeenCalledWith(2);
    expect(
      TestBed.inject(CustomerStore)
        .customers()
        .map((c) => c.id),
    ).toEqual([1, 3]);
  });

  it('zeigt nach einem Ladefehler die Meldung und keine Kunden in der Tabelle', () => {
    const { fixture, table } = setup(throwError(() => new Error('Server nicht erreichbar')));
    // die Tabelle bleibt stehen (ein Löschfehler soll sie nicht verschwinden lassen), aber leer
    expect(table!.data()).toEqual([]);
    expect((fixture.nativeElement as HTMLElement).querySelector('[role="alert"]')?.textContent).toContain(
      'Server nicht erreichbar',
    );
  });
});
