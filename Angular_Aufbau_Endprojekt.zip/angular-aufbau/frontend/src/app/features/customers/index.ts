/*
 * Öffentliche Schnittstelle (Public API) des Kunden-Features
 *
 * Andere Features dürfen nur das verwenden, was hier exportiert wird, und
 * importieren es über '@features/customers' – nie aus Unterordnern wie
 * '@features/customers/data-access/…'. So bleibt das Innere des Features
 * austauschbar: Wer data-access umbaut, muss nur diese Datei stabil halten.
 * ESLint prüft die Regel (no-restricted-imports in eslint.config.js).
 *
 * Wer nutzt das? Die Übungsseite Signals (features/playground) zeigt Kunden
 * mit der CustomerTable an.
 *
 * → Aufbau-Handbuch „Standalone-Feature-Architektur“
 */
export type { Customer, NewCustomer } from './model/customer';
export { CustomerService, CUSTOMER_URL } from './data-access/customer-service';
export { CustomerTable } from './ui/customer-table/customer-table';
