/*
 * customer-category.ts – Kundenkategorie nach Kreditlimit
 *
 * Entstanden per Test Driven Development: erst die Tests in
 * customer-category.spec.ts, dann diese Funktion.
 *
 * Bewusst eine reine Funktion (pure function) statt einer Methode in einer
 * Komponente: gleiche Eingabe → gleiche Ausgabe, keine Abhängigkeiten.
 * Solche Funktionen sind am einfachsten zu testen – ohne TestBed, ohne Mocks.
 *
 * Verwendet in der CustomerTable (Spalte „Kategorie“).
 *
 * → Aufbau-Handbuch „Unit-Tests mit Vitest“ (Test Driven Development)
 */
import { Customer } from '../model/customer';

/** Kategorie eines Kunden: A (ab 2.000 €), B (ab 500 €), C (darunter) */
export type CustomerCategory = 'A' | 'B' | 'C';

/** Grenzen als benannte Konstanten statt „magischer Zahlen“ im Code */
export const CATEGORY_A_FROM = 2000;
export const CATEGORY_B_FROM = 500;

export function customerCategory(customer: Pick<Customer, 'credit_limit'>): CustomerCategory {
  if (customer.credit_limit >= CATEGORY_A_FROM) {
    return 'A';
  }
  if (customer.credit_limit >= CATEGORY_B_FROM) {
    return 'B';
  }
  return 'C';
}
