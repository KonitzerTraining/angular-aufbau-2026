/*
 * customer-service.spec.ts – Unit-Test für den CustomerService
 *
 * Der Test spricht NICHT mit dem echten Server: provideHttpClientTesting()
 * fängt alle Anfragen ab, und der HttpTestingController beantwortet sie mit
 * Testdaten. So laufen die Tests schnell und ohne laufendes Backend.
 *
 * → Aufbau-Handbuch „Unit-Tests mit Vitest“ (Stufe 2: den Service testen)
 */
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { CUSTOMER_URL, CustomerService } from './customer-service';
import { CUSTOMERS, createCustomer } from '../testing/customer-test-data';

describe('CustomerService', () => {
  let service: CustomerService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      // Reihenfolge wichtig: erst den HttpClient, dann die Test-Variante darüber
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    // TestBed.inject() holt Instanzen aus der Dependency Injection des Tests
    service = TestBed.inject(CustomerService);
    http = TestBed.inject(HttpTestingController);
  });

  // verify(): schlägt fehl, wenn noch unbeantwortete Anfragen offen sind
  afterEach(() => http.verify());

  it('lädt alle Kunden per GET', () => {
    let count = 0;
    // subscribe() startet die Anfrage – ohne subscribe() schickt HttpClient nichts ab
    service.getAll().subscribe((customers) => (count = customers.length));
    // genau eine Anfrage an diese URL erwartet
    const request = http.expectOne(CUSTOMER_URL);
    expect(request.request.method).toBe('GET');
    // flush(): beantwortet die Anfrage mit Testdaten – erst jetzt läuft der subscribe-Callback
    request.flush([...CUSTOMERS]);
    expect(count).toBe(CUSTOMERS.length);
  });

  it('lädt einen Kunden per GET auf /customers/:id', () => {
    // Fabrik-Funktion aus Stufe 1: nur die Felder angeben, auf die es ankommt
    const customer = createCustomer({ id: 3, name: 'Dora' });
    const received = vi.fn();
    service.getById(3).subscribe(received);

    const request = http.expectOne(CUSTOMER_URL + 3);
    expect(request.request.method).toBe('GET');
    request.flush(customer);

    expect(received).toHaveBeenCalledWith(customer);
  });

  it('legt einen Kunden per POST an und liefert ihn mit id zurück', () => {
    const created = vi.fn();
    service.postOne({ name: 'Neu', credit_limit: 700 }).subscribe(created);
    const request = http.expectOne(CUSTOMER_URL);
    expect(request.request.method).toBe('POST');
    // der Body der Anfrage enthält genau die übergebenen Daten
    expect(request.request.body).toEqual({ name: 'Neu', credit_limit: 700 });
    request.flush({ id: 42, name: 'Neu', credit_limit: 700 });
    expect(created).toHaveBeenCalledWith({ id: 42, name: 'Neu', credit_limit: 700 });
  });

  it('ändert einen Kunden per PUT auf /customers/:id', () => {
    const customer = createCustomer({ id: 5 });
    service.putOne(customer).subscribe();
    const request = http.expectOne(CUSTOMER_URL + 5);
    expect(request.request.method).toBe('PUT');
    request.flush(customer);
  });

  it('reicht Serverfehler an den Aufrufer weiter', () => {
    const error = vi.fn();
    service.getAll().subscribe({ error });
    // Fehlerantwort simulieren: Status 500
    http.expectOne(CUSTOMER_URL).flush('kaputt', { status: 500, statusText: 'Server Error' });
    expect(error).toHaveBeenCalledOnce();
  });

  it('löscht per DELETE', () => {
    service.deleteById(7).subscribe();
    const request = http.expectOne(CUSTOMER_URL + 7);
    expect(request.request.method).toBe('DELETE');
    request.flush(null);
  });
});
