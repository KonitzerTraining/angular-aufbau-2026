/*
 * customer-category.spec.ts – ein durchgängiges TDD-Beispiel
 *
 * Diese Tests sind VOR der Funktion customerCategory() entstanden, nach dem
 * Rhythmus von Test Driven Development:
 *
 *   1. Rot:     einen Test schreiben, der fehlschlägt (die Funktion gibt es noch nicht)
 *   2. Grün:    gerade so viel Code schreiben, dass der Test besteht
 *   3. Refactor: aufräumen, während alle Tests grün bleiben
 *
 * Die Anforderung aus dem Fachbereich: Kunden werden nach Kreditlimit in
 * Kategorien eingeteilt – A ab 2.000 €, B ab 500 €, darunter C.
 * Jede Grenze bekommt einen eigenen Test, denn Fehler stecken fast immer an
 * den Rändern („ab 500“ heißt: 500 gehört schon zu B).
 *
 * Ausführen: npm test (Watch-Modus) – speichert man die Datei, laufen die
 * betroffenen Tests sofort neu.
 *
 * → Aufbau-Handbuch „Unit-Tests mit Vitest“ (Test Driven Development)
 */
import { customerCategory } from './customer-category';
import { createCustomer } from '../testing/customer-test-data';

// describe: fasst zusammengehörige Tests zu einer Gruppe zusammen (erscheint in der Ausgabe)
describe('customerCategory', () => {
  // it: ein einzelner Testfall – der Text liest sich als Satz: „it ordnet …“
  it('ordnet Kunden ab 2.000 € der Kategorie A zu', () => {
    // expect(ist).toBe(soll) – toBe vergleicht mit === (für Zahlen und Texte)
    expect(customerCategory(createCustomer({ credit_limit: 2000 }))).toBe('A');
    expect(customerCategory(createCustomer({ credit_limit: 10_000 }))).toBe('A');
  });

  it('ordnet Kunden von 500 € bis unter 2.000 € der Kategorie B zu', () => {
    expect(customerCategory(createCustomer({ credit_limit: 500 }))).toBe('B');
    expect(customerCategory(createCustomer({ credit_limit: 1999.99 }))).toBe('B');
  });

  it('ordnet Kunden unter 500 € der Kategorie C zu', () => {
    expect(customerCategory(createCustomer({ credit_limit: 499.99 }))).toBe('C');
    expect(customerCategory(createCustomer({ credit_limit: 0 }))).toBe('C');
  });

  // it.each: derselbe Test mit mehreren Datensätzen – eine Zeile pro Fall
  it.each([
    [2500, 'A'],
    [500, 'B'],
    [123, 'C'],
  ] as const)('liefert für %d € die Kategorie %s', (limit, category) => {
    expect(customerCategory(createCustomer({ credit_limit: limit }))).toBe(category);
  });
});
