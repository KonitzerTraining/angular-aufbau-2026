/*
 * customer-store.ts – zentraler Zustand der Kundenverwaltung mit dem NgRx SignalStore
 *
 * Ohne Store hält jede Komponente ihren Zustand selbst (customers, loading,
 * errorMessage in CustomerList). Das geht gut, solange nur EINE Komponente die
 * Daten braucht. Sobald mehrere Stellen dieselben Kunden anzeigen oder ändern,
 * entstehen Kopien, die auseinanderlaufen. Der Store hält den Zustand an
 * genau einer Stelle; Komponenten lesen ihn über Signals und ändern ihn nur
 * über die Methoden des Stores.
 *
 * Bausteine eines signalStore (von oben nach unten gelesen):
 *   withState    – der Zustand selbst; jede Eigenschaft wird automatisch ein Signal
 *   withComputed – abgeleitete Werte (wie computed() in einer Komponente)
 *   withMethods  – die einzigen Wege, den Zustand zu ändern (patchState)
 *
 * Warum SignalStore und nicht Classic NgRx? Für neue Projekte ist er die
 * schlankere Wahl: kein Boilerplate aus Actions/Reducern/Effects, voll auf
 * Signals ausgelegt. Auch die Anmeldung läuft über einen SignalStore
 * (features/auth/data-access/auth-store.ts); Classic NgRx für Bestandsprojekte
 * beschreibt das Handbuch im Kapitel „Classic NgRx in bestehenden Projekten“.
 *
 * → Aufbau-Handbuch „NgRx SignalStore“
 */
import { computed, inject } from '@angular/core';
import { patchState, signalStore, withComputed, withMethods, withState } from '@ngrx/signals';
import { rxMethod } from '@ngrx/signals/rxjs-interop';
import { tapResponse } from '@ngrx/operators';
import { mergeMap, pipe, switchMap, tap } from 'rxjs';
import { Customer } from '../model/customer';
import { CustomerService } from './customer-service';

/** Form des Zustands – nur Daten, keine Logik */
interface CustomerState {
  customers: Customer[];
  loading: boolean;
  error: string | null;
  /** Suchbegriff aus dem Eingabefeld über der Liste */
  filter: string;
}

/** Startzustand beim ersten Zugriff auf den Store */
const initialState: CustomerState = {
  customers: [],
  loading: false,
  error: null,
  filter: '',
};

export const CustomerStore = signalStore(
  // providedIn: 'root' – eine Store-Instanz für die ganze Anwendung (wie ein Service).
  // Ohne diese Option müsste eine Komponente den Store in providers eintragen;
  // dann hätte jede Instanz der Komponente ihren eigenen Store.
  { providedIn: 'root' },

  // store.customers(), store.loading(), store.error(), store.filter() – jeweils ein Signal
  withState(initialState),

  // abgeleitete Werte: werden nur neu berechnet, wenn sich ihre Quellen ändern
  withComputed(({ customers, filter }) => ({
    /** Kunden, deren Name den Suchbegriff enthält (Groß-/Kleinschreibung egal) */
    filteredCustomers: computed(() => {
      const term = filter().trim().toLowerCase();
      return term ? customers().filter((c) => c.name.toLowerCase().includes(term)) : customers();
    }),
    count: computed(() => customers().length),
    /** Summe aller Kreditlimits – Beispiel für eine Kennzahl im Store */
    totalCreditLimit: computed(() => customers().reduce((sum, c) => sum + c.credit_limit, 0)),
  })),

  // Methoden: Der zweite Parameter holt Abhängigkeiten per inject()
  withMethods((store, customerService = inject(CustomerService)) => ({
    /** Suchbegriff setzen – synchron, deshalb reicht patchState */
    setFilter(filter: string): void {
      // patchState: ändert nur die genannten Eigenschaften, der Rest bleibt
      patchState(store, { filter });
    },

    /**
     * Alle Kunden laden.
     * rxMethod verbindet den Store mit RxJS: Jeder Aufruf von load() schickt
     * einen Wert in die Pipeline. switchMap bricht eine noch laufende Anfrage
     * ab, wenn load() erneut aufgerufen wird – es gewinnt immer die neueste.
     */
    load: rxMethod<void>(
      pipe(
        tap(() => patchState(store, { loading: true, error: null })),
        switchMap(() =>
          customerService.getAll().pipe(
            // tapResponse: next und error an einer Stelle; ein Fehler beendet
            // die Pipeline NICHT – load() funktioniert danach weiter
            tapResponse({
              next: (customers) => patchState(store, { customers, loading: false }),
              error: (e: Error) =>
                patchState(store, { error: 'Kunden konnten nicht geladen werden: ' + e.message, loading: false }),
            }),
          ),
        ),
      ),
    ),

    /**
     * Einen Kunden löschen und aus dem Zustand entfernen.
     * mergeMap statt switchMap: Löscht man zwei Kunden schnell nacheinander,
     * sollen BEIDE Anfragen durchlaufen.
     */
    remove: rxMethod<number>(
      pipe(
        mergeMap((id) =>
          customerService.deleteById(id).pipe(
            tapResponse({
              // patchState mit Funktion: neuer Zustand aus dem alten (unveränderlich, filter erzeugt ein neues Array)
              next: () => patchState(store, (state) => ({ customers: state.customers.filter((c) => c.id !== id) })),
              error: (e: Error) => patchState(store, { error: 'Löschen fehlgeschlagen: ' + e.message }),
            }),
          ),
        ),
      ),
    ),
  })),
);
