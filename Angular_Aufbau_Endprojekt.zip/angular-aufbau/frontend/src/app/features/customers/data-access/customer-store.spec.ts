/*
 * customer-store.spec.ts – den SignalStore testen
 *
 * Ein Store ist ein Service: TestBed.inject() liefert ihn, der
 * CustomerService darunter wird durch eine ng-mocks-Attrappe ersetzt.
 * Geprüft wird nur der Zustand von außen: Methode aufrufen → Signals lesen.
 *
 * → Aufbau-Handbuch „NgRx SignalStore“ (den SignalStore testen)
 */
import { TestBed } from '@angular/core/testing';
import { MockProvider } from 'ng-mocks';
import { of, throwError } from 'rxjs';
import { CustomerStore } from './customer-store';
import { CustomerService } from './customer-service';
import { CUSTOMERS } from '../testing/customer-test-data';

describe('CustomerStore', () => {
  function setup(getAll: CustomerService['getAll'] = () => of([...CUSTOMERS])) {
    const deleteById = vi.fn<CustomerService['deleteById']>(() => of({}));
    TestBed.configureTestingModule({
      providers: [MockProvider(CustomerService, { getAll: vi.fn(getAll), deleteById })],
    });
    return { store: TestBed.inject(CustomerStore), deleteById };
  }

  it('startet leer und ohne Fehler', () => {
    const { store } = setup();
    expect(store.customers()).toEqual([]);
    expect(store.loading()).toBe(false);
    expect(store.error()).toBeNull();
  });

  it('lädt Kunden und berechnet die Kennzahlen', () => {
    const { store } = setup();
    store.load();
    expect(store.customers()).toHaveLength(3);
    expect(store.count()).toBe(3);
    expect(store.totalCreditLimit()).toBe(2500 + 500 + 300);
    expect(store.loading()).toBe(false);
  });

  it('hält einen Ladefehler im Zustand fest', () => {
    const { store } = setup(() => throwError(() => new Error('Timeout')));
    store.load();
    expect(store.error()).toContain('Timeout');
    expect(store.loading()).toBe(false);
  });

  it('filtert nach Namen, unabhängig von Groß- und Kleinschreibung', () => {
    const { store } = setup();
    store.load();
    store.setFilter('ma');
    expect(store.filteredCustomers().map((c) => c.name)).toEqual(['Matt']);
    store.setFilter('');
    expect(store.filteredCustomers()).toHaveLength(3);
  });

  it('entfernt einen gelöschten Kunden aus dem Zustand', () => {
    const { store, deleteById } = setup();
    store.load();
    store.remove(1);
    expect(deleteById).toHaveBeenCalledWith(1);
    expect(store.customers().map((c) => c.id)).toEqual([2, 3]);
  });
});
