/*
 * customer.ts – das Datenmodell des CRM
 *
 * Beschreibt mit TypeScript, wie ein Kunde aussieht. Zur Laufzeit existiert
 * davon nichts mehr – das Modell dient nur dem Compiler und der
 * Autovervollständigung im Editor. Verwendet in Service, Tabelle und Formular.
 *
 * → Handbuch 9.4 „Das Datenmodell“
 */

/**
 * Ein Kunde, wie ihn die REST-API liefert
 *
 * Ablage: features/customers/model – nur Interfaces und Typen, ohne Abhängigkeiten.
 * Service, Store und Komponenten importieren von hier, nie umgekehrt.
 * → Aufbau-Handbuch „Standalone-Feature-Architektur“
 */
// interface: beschreibt nur die Form eines Objekts; die Feldnamen entsprechen
// genau den Namen in backend/db.json (deshalb credit_limit mit Unterstrich).
export interface Customer {
  id: number;
  name: string;
  credit_limit: number;
}

/** Daten für einen neuen Kunden – die id vergibt der Server */
// Omit<…, 'id'>: derselbe Typ ohne das Feld id (TypeScript-Hilfstyp)
export type NewCustomer = Omit<Customer, 'id'>;
