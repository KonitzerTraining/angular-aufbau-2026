import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

/**
 * Rahmen des Kundenbereichs; die Unterseiten erscheinen im eigenen router-outlet
 *
 * Rolle: Layout-/Rahmen-Komponente des Feature-Bereichs "customers".
 * Die Überschrift bleibt stehen, während der Router darunter zwischen Liste,
 * Neu- und Bearbeiten-Seite wechselt (verschachteltes Routing).
 *
 * → Handbuch 8.5 „Verschachteltes Routing und Router Outlets“
 */
@Component({
  selector: 'app-customers',
  imports: [RouterOutlet],
  template: `
    <h1>Kundenverwaltung</h1>
    <!-- zweiter router-outlet: hier erscheinen die children aus customers.routes.ts -->
    <router-outlet />
  `,
})
export class Customers {}
