/*
 * Testdaten für das Kunden-Feature
 *
 * Warum eine eigene Datei? Würde jeder Test seine Kunden selbst
 * zusammenbauen, stünden dieselben Objekte in zehn Dateien – und eine neue
 * Pflichteigenschaft im Modell müsste man zehnmal nachtragen. Hier liegen sie
 * an einer Stelle:
 *   - CUSTOMERS: feste Liste für Tests, die mit bekannten Werten rechnen
 *   - createCustomer(): Fabrik-Funktion für einzelne Kunden, bei der man nur
 *     überschreibt, was für den Test wichtig ist
 *   - createCustomers(anzahl): eine Liste beliebiger Länge, z. B. für Tests
 *     mit vielen Zeilen
 *
 * Die Datei endet nicht auf .spec.ts und gehört damit nicht zu den Tests
 * selbst; sie wird aber nur von Tests importiert und landet nie im Build.
 *
 * → Aufbau-Handbuch „Unit-Tests mit Vitest“ (Stufe 1: Testdaten auslagern)
 */
import { Customer } from '../model/customer';

/** Feste Testliste: je ein Kunde der Kategorien A, B und C */
// as const + readonly: kein Test kann die gemeinsame Liste versehentlich verändern
export const CUSTOMERS: readonly Customer[] = [
  { id: 1, name: 'Tim', credit_limit: 2500 },
  { id: 2, name: 'Matt', credit_limit: 500 },
  { id: 3, name: 'Dora', credit_limit: 300 },
] as const;

let nextId = 100;

/**
 * Erzeugt einen gültigen Kunden; einzelne Felder lassen sich überschreiben.
 *
 * @example createCustomer({ credit_limit: 0 })  // nur das Limit ist interessant
 */
// Partial<Customer>: alle Felder optional – Spread-Syntax überschreibt die Vorgaben
export function createCustomer(overrides: Partial<Customer> = {}): Customer {
  return { id: nextId++, name: 'Testkunde', credit_limit: 1000, ...overrides };
}

/**
 * Erzeugt eine Liste mit `anzahl` Kunden über createCustomer().
 *
 * @example createCustomers(50)  // fünfzig Zeilen für die Tabelle
 */
export function createCustomers(anzahl: number): Customer[] {
  // Array.from({ length }): ein Array mit anzahl Einträgen, jeder aus der Fabrik-Funktion
  return Array.from({ length: anzahl }, (_, i) => createCustomer({ name: `Testkunde ${i + 1}` }));
}
