import { afterNextRender, Component, ElementRef, input, linkedSignal, output, viewChild } from '@angular/core';
import { form, FormField, FormRoot, max, maxLength, min, minLength, required } from '@angular/forms/signals';
import { Customer, NewCustomer } from '../../model/customer';

/**
 * Formular für Kunden – wird beim Anlegen und beim Bearbeiten verwendet
 *
 * Rolle: wiederverwendbare Presentational Component. Sie kennt weder Service
 * noch Router: Startwerte kommen über input() herein, die eingegebenen Daten
 * gehen über output() hinaus. Was mit den Daten passiert (POST oder PUT),
 * entscheiden die Smart Components CustomerNew und CustomerEdit.
 * Die Beschriftung des Absende-Buttons kommt per Content Projection.
 *
 * Seit Angular 22 mit Signal Forms statt Reactive Forms:
 *   Reactive Forms (Angular 21)          Signal Forms (Angular 22)
 *   FormBuilder.group({ … })             form(model, schema)
 *   Validators.required                  required(path.name, { message })
 *   formControlName="name"               [formField]="customerForm.name"
 *   control.invalid && control.touched   customerForm.name().invalid() && …touched()
 *   patchValue() im effect()             linkedSignal() aus dem Input
 *   markAllAsTouched() beim Absenden     erledigt [formRoot] automatisch
 *
 * → Aufbau-Handbuch „Signal Forms“ (Das Kundenformular)
 * → Handbuch 10.3 „Das Kundenformular“ (Reactive-Forms-Fassung zum Vergleich)
 * → Handbuch 11.1 „Ein Formular für Neu und Bearbeiten“
 *
 * Ablage: features/customers/ui – Presentational Components des Features (ohne Service, ohne Router).
 * → Aufbau-Handbuch „Standalone-Feature-Architektur“
 */
@Component({
  selector: 'app-customer-form',
  // FormRoot für [formRoot] am <form>, FormField für [formField] an den Eingabefeldern
  imports: [FormRoot, FormField],
  templateUrl: './customer-form.html',
  styles: `
    /* Tailwind-Klassen für @apply bekannt machen (ohne Tailwind erneut einzubinden)
       → Handbuch 10.5 „Fehler verständlich anzeigen“ */
    @reference 'tailwindcss';

    /* roter Rahmen für ungültige Felder (Klasse per [class.invalid] gesetzt) */
    input.invalid {
      @apply border-red-500 focus:ring-red-200;
    }
    /* Fehlertext unter dem Feld */
    .error {
      @apply mt-1 mb-0 text-sm text-red-600;
    }
  `,
})
export class CustomerForm {
  /** Startwerte beim Bearbeiten */
  // optionales input(): beim Anlegen bleibt es undefined, beim Bearbeiten
  // bindet CustomerEdit [default]="customer.value()". → Handbuch 11.2 „Daten hinein: input()“
  readonly default = input<Customer>();
  /** liefert die Formulardaten beim Absenden */
  // → Handbuch 11.3 „Ereignisse hinaus: output()“
  readonly customerSubmit = output<NewCustomer>();

  /**
   * Das Model: die Formulardaten als beschreibbares Signal.
   * linkedSignal() leitet den Startwert aus dem Input default() ab – kommt beim
   * Bearbeiten der Kunde an, stehen seine Werte im Formular. Danach ist das
   * Signal beschreibbar, und [formField] schreibt jede Eingabe hinein.
   */
  protected readonly model = linkedSignal<NewCustomer>(() => {
    const customer = this.default();
    return { name: customer?.name ?? '', credit_limit: customer?.credit_limit ?? 0 };
  });

  /** FieldTree: customerForm.name, customerForm.credit_limit – jeweils mit Zustand als Signals */
  protected readonly customerForm = form(
    this.model,
    // Schema: dieselben Regeln wie zuvor mit Validators, jetzt mit Fehlermeldung je Regel
    (path) => {
      required(path.name, { message: 'Der Name ist ein Pflichtfeld.' });
      minLength(path.name, 2, { message: 'Der Name braucht 2 bis 255 Zeichen.' });
      maxLength(path.name, 255, { message: 'Der Name braucht 2 bis 255 Zeichen.' });
      min(path.credit_limit, 0, { message: 'Bitte einen Betrag ab 0 eingeben.' });
      max(path.credit_limit, 1e9, { message: 'Bitte einen Betrag bis 1 Milliarde eingeben.' });
    },
    {
      // nur bei gültigem Formular: Daten an die Eltern-Komponente melden
      submission: {
        action: async () => {
          this.customerSubmit.emit(this.model());
        },
      },
    },
  );

  /** Referenz auf das Namensfeld im Template (#nameInput) */
  private readonly nameInput = viewChild<ElementRef<HTMLInputElement>>('nameInput');

  constructor() {
    // nach der ersten Darstellung: Fokus ins Namensfeld → Handbuch 7.9 „Lebenszyklus“
    afterNextRender(() => this.nameInput()?.nativeElement.focus());
  }

  /** true, wenn das Feld ungültig ist und bereits bearbeitet wurde */
  // touched: Das Feld hatte schon einmal den Fokus. So erscheinen Fehler nicht
  // schon beim Öffnen des Formulars. → Handbuch 10.5 „Fehler verständlich anzeigen“
  protected isInvalid(field: keyof NewCustomer): boolean {
    const state = this.customerForm[field]();
    return state.invalid() && state.touched();
  }
}
