/*
 * customer-form.spec.ts – Unit-Test für das Kundenformular (Signal Forms)
 *
 * Geprüft wird das Verhalten von außen gesehen: Eingaben über das DOM,
 * Ergebnis über das output() customerSubmit und die angezeigten Fehler.
 * Solche Tests überstehen auch den Umbau von Reactive Forms auf Signal Forms.
 *
 * → Aufbau-Handbuch „Signal Forms“ (Signal Forms testen)
 * → Aufbau-Handbuch „Unit-Tests mit Vitest“ (Stufe 3: den Service mocken und die Komponente testen)
 */
import { TestBed } from '@angular/core/testing';
import { CustomerForm } from './customer-form';
import { createCustomer } from '../../testing/customer-test-data';

describe('CustomerForm', () => {
  async function setup() {
    const fixture = TestBed.createComponent(CustomerForm);
    const submitted = vi.fn();
    fixture.componentInstance.customerSubmit.subscribe(submitted);
    await fixture.whenStable();
    const el = fixture.nativeElement as HTMLElement;

    function input(id: string) {
      return el.querySelector<HTMLInputElement>('#' + id)!;
    }
    function type(id: string, value: string) {
      input(id).value = value;
      input(id).dispatchEvent(new Event('input'));
    }
    async function submit() {
      el.querySelector<HTMLButtonElement>('button[type="submit"]')!.click();
      await fixture.whenStable();
    }
    return { fixture, el, submitted, input, type, submit };
  }

  it('meldet gültige Eingaben beim Absenden', async () => {
    const { submitted, type, submit } = await setup();
    type('name', 'Neue GmbH');
    type('credit_limit', '1500');
    await submit();
    // credit_limit kommt als Zahl an, nicht als Text
    expect(submitted).toHaveBeenCalledWith({ name: 'Neue GmbH', credit_limit: 1500 });
  });

  it('meldet nichts bei ungültigen Eingaben und zeigt alle Fehler', async () => {
    const { el, submitted, type, submit } = await setup();
    type('name', 'X');
    type('credit_limit', '-1');
    await submit();
    expect(submitted).not.toHaveBeenCalled();
    expect(el.textContent).toContain('Der Name braucht 2 bis 255 Zeichen.');
    expect(el.textContent).toContain('Bitte einen Betrag ab 0 eingeben.');
  });

  it('übernimmt Startwerte aus dem Input default', async () => {
    const { fixture, input } = await setup();
    fixture.componentRef.setInput('default', createCustomer({ name: 'Dora', credit_limit: 300 }));
    await fixture.whenStable();
    expect(input('name').value).toBe('Dora');
    expect(input('credit_limit').value).toBe('300');
  });
});
