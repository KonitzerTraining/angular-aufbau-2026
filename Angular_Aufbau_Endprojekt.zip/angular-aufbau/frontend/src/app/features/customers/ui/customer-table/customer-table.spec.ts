/*
 * customer-table.spec.ts – Unit-Test für die Kundentabelle
 *
 * Eine Presentational Component lässt sich besonders leicht testen:
 * Inputs setzen, Darstellung prüfen, Outputs abhören – ohne Service-Attrappen.
 * Für confirm() gibt ein Spy die Antwort vor, und am Ende ersetzt
 * MockDirective die Direktive Highlight durch eine Attrappe.
 *
 * → Aufbau-Handbuch „Unit-Tests mit Vitest“ (Stufe 4: weitere Abhängigkeiten wegmocken)
 */
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { LOCALE_ID } from '@angular/core';
import { MockDirective } from 'ng-mocks';
import { Highlight } from '@shared/directives/highlight';
import { CustomerTable } from './customer-table';
import { CUSTOMERS, createCustomers } from '../../testing/customer-test-data';

// Deutsche Formate registriert src/test-setup.ts für alle Tests.
// Testdaten kommen aus testing/customer-test-data.ts (Stufe 1: Testdaten auslagern)
const customers = [...CUSTOMERS];

describe('CustomerTable', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [CustomerTable],
      // Router für routerLink, LOCALE_ID für die deutsche currency-Pipe
      providers: [provideRouter([]), { provide: LOCALE_ID, useValue: 'de-DE' }],
    });
  });

  it('zeigt eine Zeile pro Kunde mit deutschem Betrag', () => {
    const fixture = TestBed.createComponent(CustomerTable);
    // setInput(): setzt ein Signal-Input wie ein [data]="…" im Template
    fixture.componentRef.setInput('data', customers);
    // detectChanges(): Template jetzt darstellen
    fixture.detectChanges();
    const rows = (fixture.nativeElement as HTMLElement).querySelectorAll('tbody tr');
    expect(rows.length).toBe(3);
    expect(rows[0].textContent).toContain('2.500,00');
  });

  it('zeigt die Kategorie je Kunde (A, B, C)', () => {
    const fixture = TestBed.createComponent(CustomerTable);
    fixture.componentRef.setInput('data', customers);
    fixture.detectChanges();
    const badges = [...(fixture.nativeElement as HTMLElement).querySelectorAll('.badge')].map((b) => b.textContent?.trim());
    // toEqual vergleicht Inhalte (Arrays, Objekte) statt Referenzen
    expect(badges).toEqual(['A', 'B', 'C']);
  });

  it('meldet nichts, wenn das Löschen abgebrochen wird', () => {
    // Spy mit Antwort "Abbrechen"
    const confirmSpy = vi.spyOn(window, 'confirm').mockReturnValue(false);
    const fixture = TestBed.createComponent(CustomerTable);
    fixture.componentRef.setInput('data', customers);
    fixture.detectChanges();
    // vi.fn(): eine leere Funktion, die sich merkt, ob und wie sie aufgerufen wurde
    const listener = vi.fn();
    fixture.componentInstance.deleteEvent.subscribe(listener);
    (fixture.nativeElement as HTMLElement).querySelector<HTMLButtonElement>('button.btn-danger')!.click();
    expect(confirmSpy).toHaveBeenCalledOnce();
    expect(listener).not.toHaveBeenCalled();
  });

  it('meldet die id beim Löschen', () => {
    // vi.spyOn(): ersetzt window.confirm, damit kein Dialog erscheint – Antwort "OK"
    vi.spyOn(window, 'confirm').mockReturnValue(true);
    const fixture = TestBed.createComponent(CustomerTable);
    fixture.componentRef.setInput('data', customers);
    fixture.detectChanges();
    let deletedId = 0;
    // ein output() lässt sich im Test wie ein Observable abonnieren
    fixture.componentInstance.deleteEvent.subscribe((id) => (deletedId = id));
    // Klick auf den ersten Löschen-Button simulieren
    (fixture.nativeElement as HTMLElement).querySelector<HTMLButtonElement>('button.btn-danger')!.click();
    expect(deletedId).toBe(1);
  });

  it('zeigt auch lange Listen vollständig an', () => {
    const fixture = TestBed.createComponent(CustomerTable);
    // createCustomers(): beliebig viele Testkunden aus der Fabrik-Funktion
    fixture.componentRef.setInput('data', createCustomers(25));
    fixture.detectChanges();
    expect((fixture.nativeElement as HTMLElement).querySelectorAll('tbody tr')).toHaveLength(25);
  });
});

describe('CustomerTable mit MockDirective(Highlight)', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [CustomerTable],
      providers: [provideRouter([]), { provide: LOCALE_ID, useValue: 'de-DE' }],
    });
    // die echte Direktive aus den imports der Tabelle gegen eine Attrappe tauschen –
    // overrideComponent() muss vor createComponent() stehen
    TestBed.overrideComponent(CustomerTable, {
      remove: { imports: [Highlight] },
      add: { imports: [MockDirective(Highlight)] },
    });
  });

  it('färbt die Zeile beim Überfahren nicht, weil die Attrappe nichts tut', () => {
    const fixture = TestBed.createComponent(CustomerTable);
    fixture.componentRef.setInput('data', customers);
    fixture.detectChanges();
    const row = (fixture.nativeElement as HTMLElement).querySelector<HTMLTableRowElement>('tbody tr')!;
    row.dispatchEvent(new Event('mouseenter'));
    fixture.detectChanges();
    expect(row.style.backgroundColor).toBe('');
    // die Tabelle selbst funktioniert weiter
    expect(row.textContent).toContain('Tim');
  });
});
