# Architektur des CRM

```
src/app/
├── app.ts, app.config.ts, app.routes.ts   Rahmen: Start, Provider, Routen der obersten Ebene
├── core/                                  gibt es genau einmal: Layout, Navigation (abhängig vom Login)
├── pages/                                 kleine, statische Seiten: Start, Über uns, 404
├── features/                              fachliche Bereiche, jeder lazy geladen
│   ├── customers/                         Kundenverwaltung
│   │   ├── index.ts                       öffentliche Schnittstelle für andere Features
│   │   ├── customers.routes.ts            Routen des Features (Liste, Neu, Bearbeiten)
│   │   ├── model/                         Interfaces und Typen, ohne Abhängigkeiten
│   │   ├── data-access/                   Service und SignalStore
│   │   ├── ui/                            Presentational Components (Tabelle, Formular)
│   │   ├── views/                         Smart Components je Route
│   │   └── testing/                       Testdaten für die Unit-Tests
│   ├── auth/                              Anmeldung (AuthStore, Login mit Reactive Forms, Guards)
│   └── playground/                        Übungsseiten aus dem Grundlagenkurs
└── shared/                                fachneutral und wiederverwendbar
    ├── ui/                                MessageBox, LoadingIndicator, ValueList, InfoCard
    ├── directives/                        Highlight
    └── pipes/                             TaxPipe
```

## Regeln

| Regel | Warum | Geprüft durch |
|---|---|---|
| Abhängigkeiten zeigen nur nach unten: app → core → features → shared | keine Kreise, jede Ebene ist für sich testbar | ESLint `no-restricted-imports` |
| shared importiert nichts aus features oder core | wiederverwendbar, auch in anderen Projekten | ESLint |
| Ein Feature nutzt ein anderes nur über dessen Einstieg `@features/<name>` (Datei `index.ts`) | das Innere eines Features bleibt austauschbar | ESLint |
| Jedes Feature bringt eine eigene `*.routes.ts` mit und wird per `loadChildren` geladen | kleines Start-Bundle, Features lassen sich verschieben | Code-Review, `ng build` zeigt die Lazy Chunks |
| Imports über Aliase: `@core/…`, `@shared/…`, `@features/…`, `@env/…` | kurze, stabile Pfade; die Ebene steht im Import | `tsconfig.json` (`paths`) |

→ Aufbau-Handbuch „Standalone-Feature-Architektur“
