import { computed, Directive, input, signal } from '@angular/core';

/**
 * Attribut-Direktive: hebt das Element hervor, solange die Maus darüber ist
 *
 * Verwendung: `<tr appHighlight>` oder `<tr appHighlight="#dbeafe">`
 *
 * Im CRM hebt sie die Zeilen der Kundentabelle und die Liste auf der
 * Template-Syntax-Seite hervor. Eine Direktive hat – anders als eine
 * Komponente – kein eigenes Template; sie verändert ein vorhandenes Element.
 *
 * → Handbuch 6.12 „Eigene Direktive: Highlight“
 *
 * Ablage: shared/directives – fachneutral und wiederverwendbar.
 * → Aufbau-Handbuch „Standalone-Feature-Architektur“
 */
@Directive({
  // eckige Klammern: Attribut-Selektor, greift bei jedem Element mit appHighlight
  selector: '[appHighlight]',
  // host: Bindings auf das Element, an dem die Direktive sitzt (das "Host-Element")
  host: {
    // Event Binding auf Mausereignisse des Host-Elements
    '(mouseenter)': 'active.set(true)',
    '(mouseleave)': 'active.set(false)',
    // Style Binding: Hintergrundfarbe nur, solange active() true ist; null entfernt den Stil
    '[style.backgroundColor]': 'active() ? color() : null',
  },
})
export class Highlight {
  /** Farbe der Hervorhebung; ohne Wert (`<tr appHighlight>`) kommt ein leerer String an */
  // Das Input heißt wie der Selektor – so lässt sich der Wert direkt am Attribut übergeben.
  readonly appHighlight = input('');
  /** verwendete Farbe: angegebener Wert oder Hellgelb */
  protected readonly color = computed(() => this.appHighlight() || '#fff3cd');
  // interner Zustand als Signal, damit Angular die Änderung bemerkt (zoneless)
  // → Handbuch 7.6 „Zoneless: warum normale Felder nicht reichen“
  protected readonly active = signal(false);
}
