/*
 * highlight.spec.ts – Direktiven testen über eine Host-Komponente
 *
 * Eine Direktive hat kein eigenes Template. Man testet sie deshalb in einer
 * kleinen Test-Komponente, die sie verwendet, und prüft deren DOM.
 *
 * → Aufbau-Handbuch „Unit-Tests mit Vitest“ (Bausteine ohne Abhängigkeiten)
 * → Handbuch 6.12 „Eigene Direktive: Highlight“
 */
import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Highlight } from './highlight';

// Host-Komponente nur für den Test: einmal mit Standardfarbe, einmal mit eigener Farbe
@Component({
  imports: [Highlight],
  template: `
    <p id="standard" appHighlight>Standard</p>
    <p id="eigen" appHighlight="lightblue">Eigene Farbe</p>
  `,
})
class HostComponent {}

describe('Highlight', () => {
  function setup(id: string) {
    const fixture = TestBed.createComponent(HostComponent);
    fixture.detectChanges();
    const p = (fixture.nativeElement as HTMLElement).querySelector<HTMLElement>('#' + id)!;
    return { fixture, p };
  }

  it('färbt beim Überfahren mit der Standardfarbe und setzt sie danach zurück', () => {
    const { fixture, p } = setup('standard');
    // Maus-Ereignis auslösen, dann neu darstellen lassen
    p.dispatchEvent(new Event('mouseenter'));
    fixture.detectChanges();
    expect(p.style.backgroundColor).toBe('rgb(255, 243, 205)'); // = #fff3cd
    p.dispatchEvent(new Event('mouseleave'));
    fixture.detectChanges();
    expect(p.style.backgroundColor).toBe('');
  });

  it('verwendet die übergebene Farbe', () => {
    const { fixture, p } = setup('eigen');
    p.dispatchEvent(new Event('mouseenter'));
    fixture.detectChanges();
    expect(p.style.backgroundColor).toBe('lightblue');
  });
});
