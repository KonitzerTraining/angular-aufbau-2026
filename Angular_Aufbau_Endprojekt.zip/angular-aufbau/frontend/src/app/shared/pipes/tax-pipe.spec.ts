/*
 * tax-pipe.spec.ts – Unit-Test für die TaxPipe
 *
 * Eine Pipe ist eine einfache Klasse: Für den Test genügt `new TaxPipe()`,
 * TestBed ist nicht nötig.
 *
 * → Handbuch 6.11 „Eigene Pipe: TaxPipe“
 * → Handbuch 12.4 „Unit-Tests mit Vitest“
 */
import { TaxPipe } from './tax-pipe';

describe('TaxPipe', () => {
  const pipe = new TaxPipe();

  it('rechnet standardmäßig 19 % auf', () => {
    // toBeCloseTo statt toBe: Kommazahlen sind im Rechner nicht immer exakt (Rundungsfehler)
    expect(pipe.transform(100)).toBeCloseTo(119);
  });

  it('nimmt einen anderen Steuersatz an', () => {
    expect(pipe.transform(100, 7)).toBeCloseTo(107);
  });
});
