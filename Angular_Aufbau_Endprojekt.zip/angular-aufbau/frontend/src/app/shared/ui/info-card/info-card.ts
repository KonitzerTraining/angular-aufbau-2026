import { Component, input } from '@angular/core';

/**
 * Hinweiskarte – auf der Template-Syntax-Seite nur innerhalb von @defer verwendet,
 * damit Angular sie in eine eigene Datei auslagert und erst bei Bedarf lädt
 *
 * Rolle: kleine Presentational Component (gemeinsamer Baustein unter shared/ui/).
 * Sie bekommt den Titel über input() und den Inhalt über Content Projection.
 *
 * → Handbuch 6.8 „Control Flow: Bedingungen und Schleifen“ (verzögertes Laden mit defer)
 * → Handbuch 11.6 „Inhalte hineinreichen: Content Projection“
 * → Handbuch 11.8 „Gemeinsame Bausteine ablegen“
 *
 * Ablage: shared/ui – fachneutraler Baustein, darf in jedem Feature verwendet werden, kennt selbst kein Feature.
 * → Aufbau-Handbuch „Standalone-Feature-Architektur“
 */
@Component({
  selector: 'app-info-card',
  // Inline-Template: bei kleinen Komponenten steht das HTML direkt in der Klasse.
  // → Handbuch 5.2 „Aufbau einer Komponente“
  template: `
    <div class="mb-4 rounded-lg border border-blue-200 bg-blue-50 p-4">
      <!-- title() liest das Signal-Input -->
      <h3 class="mt-0">{{ title() }}</h3>
      <!-- hier erscheint alles, was die Eltern-Komponente zwischen die Tags schreibt -->
      <ng-content />
    </div>
  `,
})
export class InfoCard {
  /** Überschrift der Karte */
  // input.required(): Pflicht-Input – fehlt title="…" beim Einbinden, meldet
  // der Compiler einen Fehler. → Handbuch 11.2 „Daten hinein: input()“
  readonly title = input.required<string>();
}
