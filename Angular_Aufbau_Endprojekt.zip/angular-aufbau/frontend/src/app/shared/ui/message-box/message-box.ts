import { Component, input } from '@angular/core';

/** Art der Meldung */
// Union-Type: nur diese vier Texte sind erlaubt – Tippfehler meldet der Compiler.
export type MessageType = 'info' | 'success' | 'warning' | 'danger';

/**
 * Zeigt eine Meldung an – nur wenn `message` gesetzt ist
 *
 * Rolle: Presentational Component (gemeinsamer Baustein unter shared/ui/).
 * Im CRM zeigt sie Fehlermeldungen in Kundenliste, Neu- und Bearbeiten-Seite.
 *
 * → Handbuch 9.8 „Ladezustand und Fehler anzeigen“
 * → Handbuch 11.2 „Daten hinein: input()“
 * → Handbuch 11.8 „Gemeinsame Bausteine ablegen“
 *
 * Ablage: shared/ui – fachneutraler Baustein, darf in jedem Feature verwendet werden, kennt selbst kein Feature.
 * → Aufbau-Handbuch „Standalone-Feature-Architektur“
 */
@Component({
  selector: 'app-message-box',
  template: `
    <!-- Ohne Text (null oder leer) wird gar nichts dargestellt -->
    @if (message()) {
      <!-- [class] bindet einen ganzen Klassen-String; role="alert" für Screenreader -->
      <div class="mb-4 rounded-md border px-4 py-3" [class]="colors[type()]" role="alert">
        {{ message() }}
      </div>
    }
  `,
})
export class MessageBox {
  /** Text der Meldung; `null` blendet die Box aus */
  // input() mit Startwert: ohne Binding ist der Wert null
  readonly message = input<string | null>(null);
  /** Darstellung der Meldung */
  // Statischer Wert reicht beim Einbinden: <app-message-box type="danger" />
  readonly type = input<MessageType>('info');

  /** Tailwind-Klassen je Meldungsart */
  // Record<MessageType, string>: TypeScript prüft, dass jede Meldungsart einen Eintrag hat.
  // → Handbuch 6.4 „Styles und Klassen binden“
  protected readonly colors: Record<MessageType, string> = {
    info: 'border-sky-200 bg-sky-50 text-sky-800',
    success: 'border-green-200 bg-green-50 text-green-800',
    warning: 'border-amber-200 bg-amber-50 text-amber-800',
    danger: 'border-red-200 bg-red-50 text-red-800',
  };
}
