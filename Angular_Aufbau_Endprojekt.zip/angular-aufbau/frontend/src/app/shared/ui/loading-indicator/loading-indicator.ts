import { Component } from '@angular/core';

/**
 * Ladeanzeige (drehender Kreis)
 *
 * Rolle: Presentational Component ohne Inputs und Logik – ein reiner Baustein.
 * Im CRM erscheint sie in der Kundenliste, beim Anlegen und Bearbeiten, solange
 * auf den Server gewartet wird, und als Ladeanzeige im defer-Block der
 * Template-Syntax-Seite.
 *
 * → Handbuch 9.8 „Ladezustand und Fehler anzeigen“
 * → Handbuch 11.8 „Gemeinsame Bausteine ablegen“
 *
 * Ablage: shared/ui – fachneutraler Baustein, darf in jedem Feature verwendet werden, kennt selbst kein Feature.
 * → Aufbau-Handbuch „Standalone-Feature-Architektur“
 */
@Component({
  selector: 'app-loading-indicator',
  template: `
    <!-- role="status" kündigt die Ladeanzeige Screenreadern an (Barrierefreiheit) -->
    <div class="my-12 flex justify-center" role="status">
      <!-- Tailwind: animate-spin dreht den Kreis, border-t-blue-600 färbt nur den oberen Rand -->
      <div class="size-10 animate-spin rounded-full border-4 border-slate-200 border-t-blue-600"></div>
      <!-- sr-only: unsichtbar, aber für Screenreader lesbar -->
      <span class="sr-only">Lädt …</span>
    </div>
  `,
})
export class LoadingIndicator {}
