import { Component, computed, input } from '@angular/core';
import { DecimalPipe } from '@angular/common';

/**
 * Kind-Komponente für die Template-Syntax-Seite:
 * Daten per input(), Überschrift per Content Projection
 *
 * Rolle: Presentational Component. Sie zeigt eine Zahlenliste samt Summe und
 * kennt weder Services noch Router.
 *
 * → Handbuch 5.7 „Daten an Komponenten übergeben“
 * → Handbuch 7.3 „computed(): abgeleitete Werte“
 * → Handbuch 11.6 „Inhalte hineinreichen: Content Projection“
 *
 * Ablage: shared/ui – fachneutraler Baustein, darf in jedem Feature verwendet werden, kennt selbst kein Feature.
 * → Aufbau-Handbuch „Standalone-Feature-Architektur“
 */
@Component({
  selector: 'app-value-list',
  // Pipes müssen wie Komponenten importiert werden, bevor das Template sie nutzt
  imports: [DecimalPipe],
  template: `
    <div class="mb-4 rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
      <!-- select="h3": nur h3-Elemente aus dem projizierten Inhalt landen hier -->
      <ng-content select="h3" />
      <ul>
        <!-- track $index: Zahlen haben keine id, deshalb dient die Position als Schlüssel -->
        @for (value of data(); track $index) {
          <!-- number-Pipe: mindestens 1 Vorkommastelle, genau 2 Nachkommastellen -->
          <li>{{ value | number: '1.2-2' }}</li>
        }
      </ul>
      <p class="font-semibold">Summe: {{ sum() | number: '1.2-2' }}</p>
      <!-- ng-content ohne select: der gesamte übrige Inhalt -->
      <ng-content />
    </div>
  `,
})
export class ValueList {
  /** Zahlen, die angezeigt werden */
  // Signal-Input mit Startwert [] – die Eltern-Komponente bindet [data]="…"
  // → Handbuch 7.7 „Signal-Inputs“
  readonly data = input<number[]>([]);
  /** Summe aller Werte */
  // computed() rechnet automatisch neu, sobald sich data() ändert
  readonly sum = computed(() => this.data().reduce((a, b) => a + b, 0));
}
