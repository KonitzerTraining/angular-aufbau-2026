import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Navigation } from '@core/layout/navigation/navigation';

/**
 * Root-Komponente der Anwendung
 *
 * Rolle: Wurzel des Komponentenbaums. main.ts startet sie, Angular setzt sie in
 * index.html an die Stelle von <app-root>. Ihr Template (app.html) enthält den
 * festen Rahmen jeder Seite: oben die Navigation, darunter den <router-outlet />,
 * in dem der Router die jeweilige Seite einblendet.
 *
 * → Handbuch 3.4 „Bootstrapping: der Start der Anwendung“
 * → Handbuch 4.6 „Alles zusammensetzen“
 * → Handbuch 5.1 „Der Komponentenbaum des CRM“
 * → Handbuch 5.2 „Aufbau einer Komponente“
 */
@Component({
  // CSS-Selektor: unter diesem Tag-Namen erscheint die Komponente im HTML
  selector: 'app-root',
  // Standalone: alles, was das Template verwendet, wird hier importiert.
  // → Handbuch 5.4 „Komponenten einbinden“
  imports: [RouterOutlet, Navigation],
  // Template in einer eigenen Datei (statt inline mit template: `…`)
  templateUrl: './app.html',
})
export class App {
  /** Titel der Anwendung, erscheint in der Navigation */
  // signal() legt einen reaktiven Wert an; im Template wird er mit title() gelesen.
  // protected: nur Klasse und Template greifen darauf zu, nicht andere Klassen.
  // → Handbuch 7.2 „signal(): Zustand anlegen, lesen und ändern“
  protected readonly title = signal('CRM v3.0');
}
