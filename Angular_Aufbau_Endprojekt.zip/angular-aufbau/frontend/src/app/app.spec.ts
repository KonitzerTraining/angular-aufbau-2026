/*
 * app.spec.ts – Unit-Test für die Root-Komponente App
 *
 * Prüft, dass der Titel aus dem Signal in der Navigation ankommt.
 * Ausführen mit: npx ng test (Test-Runner: Vitest)
 *
 * → Handbuch 12.4 „Unit-Tests mit Vitest“
 */
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { MockProvider } from 'ng-mocks';
import { AuthService } from '@features/auth/data-access/auth-service';
import { App } from './app';

// describe() fasst zusammengehörige Tests zu einer Gruppe zusammen
describe('App', () => {
  // beforeEach() läuft vor jedem einzelnen Test
  beforeEach(async () => {
    // TestBed baut eine kleine Test-Umgebung, ähnlich wie app.config.ts für die echte App
    await TestBed.configureTestingModule({
      imports: [App],
      // App verwendet RouterOutlet und die Navigation (routerLink) – dafür
      // braucht es einen Router; eine leere Routen-Tabelle genügt.
      // die Navigation liest den AuthStore; dessen AuthService
      // braucht hier keinen Server → durch eine leere Attrappe ersetzen
      providers: [provideRouter([]), MockProvider(AuthService)],
    }).compileComponents();
  });

  // it() beschreibt einen einzelnen Testfall
  it('zeigt den Titel in der Navigation', async () => {
    const fixture = TestBed.createComponent(App);
    // warten, bis Angular das Template dargestellt hat
    await fixture.whenStable();
    const nav = (fixture.nativeElement as HTMLElement).querySelector('app-navigation');
    // expect(…).toContain(…) – die eigentliche Prüfung
    expect(nav?.textContent).toContain('CRM v3.0');
  });
});
