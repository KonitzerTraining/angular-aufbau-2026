/*
 * app.config.ts – die globale Konfiguration der Anwendung
 *
 * Hier wird festgelegt, welche Dienste (Provider) in der ganzen Anwendung zur
 * Verfügung stehen: Router, HttpClient und die deutsche Sprache für Pipes.
 * main.ts übergibt dieses Objekt an bootstrapApplication().
 *
 * → Handbuch 3.4 „Bootstrapping: der Start der Anwendung“
 * → Handbuch 9.3 „HttpClient einschalten“
 * → Handbuch 6.10 „Lokalisierung von Zahlen und Datum“
 * → Handbuch 8.6 „Parameter-Mitnahme“
 * → Aufbau-Handbuch „Standalone-Feature-Architektur“ (Preloading)
 * Die Stores (CustomerStore, AuthStore) brauchen hier keinen Eintrag: Sie sind
 * SignalStores mit providedIn: 'root'. → Aufbau-Handbuch „NgRx SignalStore“
 */
import { ApplicationConfig, LOCALE_ID, provideBrowserGlobalErrorListeners } from '@angular/core';
import { PreloadAllModules, provideRouter, withComponentInputBinding, withPreloading } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { registerLocaleData } from '@angular/common';
import localeDe from '@angular/common/locales/de';

import { routes } from './app.routes';

// Die deutschen Formatregeln (Dezimalkomma, Tausenderpunkt, Monatsnamen) bringt
// Angular nicht von Haus aus mit – sie werden hier einmalig registriert.
// → Handbuch 6.10 „Lokalisierung von Zahlen und Datum“
registerLocaleData(localeDe);

export const appConfig: ApplicationConfig = {
  providers: [
    // leitet nicht abgefangene Fehler im Browser an Angulars ErrorHandler weiter
    provideBrowserGlobalErrorListeners(),
    // Router mit den Routen aus app.routes.ts einschalten.
    // withComponentInputBinding(): Routenparameter wie :customerId kommen
    // automatisch in ein gleichnamiges input() der Komponente (siehe CustomerEdit).
    // → Handbuch 4.4 „Routen festlegen“, → Handbuch 8.6 „Parameter-Mitnahme“
    //
    // withPreloading(PreloadAllModules) – Optimierung des Lazy Loadings:
    // Die Start-Seite erscheint so schnell wie mit reinem Lazy Loading, weil die
    // Feature-Chunks nicht im Haupt-Bundle stecken. Sobald die Anwendung steht,
    // lädt der Router die übrigen Features im Hintergrund vor – der erste Klick
    // auf „Kunden“ wartet dann nicht mehr auf das Netzwerk.
    // → Aufbau-Handbuch „Standalone-Feature-Architektur“ (Optimierung durch Lazy Loading)
    provideRouter(routes, withComponentInputBinding(), withPreloading(PreloadAllModules)),
    // HttpClient bereitstellen, damit Services per inject(HttpClient) Daten laden können.
    // Seit Angular 22 nutzt der HttpClient standardmäßig die fetch-API des Browsers;
    // withFetch() aus Angular 21 ist nicht mehr nötig.
    // → Handbuch 9.3 „HttpClient einschalten“, → Aufbau „Ausblick“ (Angular 22)
    provideHttpClient(),
    // Standard-Sprache für alle Pipes (number, currency, date): 23.004,60 € statt €23,004.60
    // → Handbuch 6.10 „Lokalisierung von Zahlen und Datum“
    { provide: LOCALE_ID, useValue: 'de-DE' },
  ],
};
