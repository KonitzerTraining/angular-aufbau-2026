/*
 * app.routes.ts – die Routen-Tabelle der Anwendung (Feature-based Routing)
 *
 * Mit der Feature-Architektur kennt diese Datei nur noch drei Arten von Einträgen:
 *   1. einfache Seiten aus pages/ (Start, Über uns, 404) – direkt importiert,
 *      sie sind klein und werden fast immer gebraucht
 *   2. Features unter features/ – jedes bringt seine eigene Routen-Datei mit
 *      und wird per loadChildren erst bei Bedarf nachgeladen (Lazy Loading)
 *   3. Weiterleitungen
 *
 * Was innerhalb eines Features passiert (Unterseiten, Parameter), steht in
 * dessen eigener *.routes.ts. So wächst diese Datei nicht mit jedem neuen
 * Bildschirm, und ein Feature lässt sich als Ganzes verschieben oder entfernen.
 *
 * → Aufbau-Handbuch „Standalone-Feature-Architektur“
 * Grundlagen dazu: → Handbuch 8.4 „Lazy Loading“, 8.5 „Verschachteltes Routing und Router Outlets“
 */
import { Routes } from '@angular/router';
import { StartPage } from './pages/start-page/start-page';
import { AboutPage } from './pages/about-page/about-page';
import { NotFoundPage } from './pages/not-found-page/not-found-page';
import { authGuard } from '@features/auth';

export const routes: Routes = [
  { path: '', redirectTo: 'start', pathMatch: 'full' },
  { path: 'start', component: StartPage, title: 'CRM – Start' },

  // Feature „customers“: Kundenliste, Neu, Bearbeiten (Fachkern des CRM)
  {
    path: 'customers',
    // nur nach Anmeldung. canActivate prüft, bevor die Seite
    // ANGEZEIGT wird. Den Code lädt der Router trotzdem (hier ohnehin per
    // Preloading). Soll schon das Nachladen unterbleiben, nimmt man canMatch.
    // → Aufbau-Handbuch „Den Store verwenden: Navigation und Guards“
    canActivate: [authGuard],
    loadChildren: () => import('./features/customers/customers.routes').then((m) => m.customerRoutes),
  },
  // Feature „auth“: Anmeldung mit dem AuthStore
  {
    path: 'login',
    loadChildren: () => import('./features/auth/auth.routes').then((m) => m.authRoutes),
  },
  // Feature „playground“: Übungsseiten aus dem Grundlagenkurs
  {
    path: 'playground',
    loadChildren: () => import('./features/playground/playground.routes').then((m) => m.playgroundRoutes),
  },

  // alte Adressen weiterleiten, damit Lesezeichen weiter funktionieren
  { path: 'template-syntax', redirectTo: 'playground/template-syntax' },
  { path: 'signals', redirectTo: 'playground/signals' },
  { path: 'dashboard', redirectTo: 'customers' },

  { path: 'about', component: AboutPage, title: 'CRM – Über uns' },
  // immer als letzte Route: '**' passt auf jede URL
  { path: '**', component: NotFoundPage, title: 'CRM – Seite nicht gefunden' },
];
