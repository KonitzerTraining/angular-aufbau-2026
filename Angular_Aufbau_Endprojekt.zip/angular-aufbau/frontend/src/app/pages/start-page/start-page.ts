import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

/**
 * Startseite
 *
 * Rolle: Seite (Routen-Komponente) für /start. Die leere Adresse '/' leitet
 * hierher weiter (redirectTo in app.routes.ts). Erzeugt mit
 * `ng generate component pages/start-page`.
 *
 * → Handbuch 4.3 „Seiten erzeugen“
 * → Handbuch 4.4 „Routen festlegen“
 */
@Component({
  selector: 'app-start-page',
  // RouterLink wird für den Button "Zur Kundenverwaltung" im Template gebraucht
  imports: [RouterLink],
  templateUrl: './start-page.html',
  styleUrl: './start-page.css',
})
export class StartPage {}
