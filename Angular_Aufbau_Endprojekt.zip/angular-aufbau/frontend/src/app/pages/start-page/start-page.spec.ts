/*
 * start-page.spec.ts – Unit-Test für die Startseite
 *
 * Smoke-Test: Lässt sich die Komponente erzeugen?
 *
 * → Handbuch 12.4 „Unit-Tests mit Vitest“
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';

import { StartPage } from './start-page';

describe('StartPage', () => {
  let component: StartPage;
  let fixture: ComponentFixture<StartPage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StartPage],
      // Die Startseite enthält einen routerLink – ohne Router-Provider schlüge der Test fehl
      providers: [provideRouter([])],
    }).compileComponents();

    fixture = TestBed.createComponent(StartPage);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
