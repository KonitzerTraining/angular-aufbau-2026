import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

/**
 * Wird für alle unbekannten URLs angezeigt (Route '**')
 *
 * Rolle: Seite (Routen-Komponente) für die Wildcard-Route am Ende von
 * app.routes.ts – etwa bei einem Tippfehler in der Adresszeile.
 *
 * → Handbuch 4.4 „Routen festlegen“
 * → Handbuch 8.2 „Alle Eigenschaften einer Route“
 */
@Component({
  selector: 'app-not-found-page',
  imports: [RouterLink],
  // Inline-Template statt eigener HTML-Datei – bei zwei Zeilen übersichtlicher
  template: `
    <h1>Seite nicht gefunden</h1>
    <!-- routerLink: Navigation innerhalb der Anwendung ohne Neuladen -->
    <p><a routerLink="/start">Zur Startseite</a></p>
  `,
})
export class NotFoundPage {}
