/*
 * about-page.spec.ts – Unit-Test für die Über-uns-Seite
 *
 * Von der CLI beim Erzeugen der Komponente mitgeliefert: Der Test prüft nur,
 * dass sich die Komponente erzeugen lässt ("Smoke-Test").
 *
 * → Handbuch 12.4 „Unit-Tests mit Vitest“
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutPage } from './about-page';

describe('AboutPage', () => {
  let component: AboutPage;
  // Die Fixture ist die Hülle um die Komponente im Test: Zugriff auf Instanz und DOM
  let fixture: ComponentFixture<AboutPage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AboutPage],
    }).compileComponents();

    fixture = TestBed.createComponent(AboutPage);
    component = fixture.componentInstance;
    // warten, bis die Darstellung abgeschlossen ist
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
