import { Component } from '@angular/core';

/**
 * Über-uns-Seite
 *
 * Rolle: Seite (Routen-Komponente) für /about, erzeugt mit
 * `ng generate component pages/about-page`. Sie enthält nur statischen Text
 * und zeigt den Grundaufbau einer Komponente aus drei Dateien
 * (TypeScript, HTML, CSS).
 *
 * → Handbuch 4.3 „Seiten erzeugen“
 * → Handbuch 5.2 „Aufbau einer Komponente“
 */
@Component({
  selector: 'app-about-page',
  // leer: das Template verwendet keine anderen Komponenten, Direktiven oder Pipes
  imports: [],
  templateUrl: './about-page.html',
  // eigene CSS-Datei, deren Regeln nur für diese Komponente gelten
  // → Handbuch 5.5 „Styles und Kapselung“
  styleUrl: './about-page.css',
})
export class AboutPage {}
