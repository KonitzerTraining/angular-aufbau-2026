/*
 * environment.ts – Einstellungen für den Produktions-Build
 *
 * Diese Datei gilt für `ng build`. Bei `ng serve` ersetzt die CLI sie durch
 * environment.development.ts (fileReplacements in angular.json).
 *
 * → Handbuch 9.2 „Die Adresse der API: Environments“
 * → Handbuch 12.6 „Den Build lokal testen mit http-server“
 * → Handbuch 12.7 „Hinweise für die Bereitstellung“
 */

/** Einstellungen für den Produktions-Build (ng build) */
export const environment = {
  // Relative Adresse: Die API liegt im Betrieb auf demselben Server unter /api/.
  // So entfallen CORS-Probleme. → Handbuch 9.14 „CORS und Proxy“
  api: '/api/',
};
