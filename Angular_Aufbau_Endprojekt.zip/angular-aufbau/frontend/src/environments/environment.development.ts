/*
 * environment.development.ts – Einstellungen für die Entwicklung
 *
 * Bei `ng serve` tauscht die CLI die Datei environment.ts gegen diese Datei aus
 * (fileReplacements in angular.json). Im Code wird immer nur
 * '…/environments/environment' importiert – welcher Inhalt ankommt, entscheidet
 * die Build-Konfiguration.
 *
 * → Handbuch 9.2 „Die Adresse der API: Environments“
 * → Handbuch 9.1 „Das Mock-Backend mit json-server“
 */

/** Einstellungen für die Entwicklung (ng serve) */
export const environment = {
  // json-server aus dem Ordner backend/ läuft lokal auf Port 3001.
  // Der abschließende Schrägstrich ist wichtig: CustomerService hängt 'customers/' an.
  api: 'http://localhost:3001/',
};
