/*
 * playwright.config.ts – Einstellungen für die E2E-Tests mit Playwright
 *
 * E2E-Tests (End-to-End) steuern einen echten Browser und prüfen die
 * Anwendung so, wie Anwender sie benutzen: Seite öffnen, klicken, tippen,
 * Ergebnis ansehen. Unit-Tests (Vitest) prüfen einzelne Bausteine – E2E-Tests
 * prüfen das Zusammenspiel.
 *
 * Eingerichtet mit `ng add playwright-ng-schematics`. Ausführen:
 *   npx ng e2e         alle E2E-Tests; startet den Entwicklungsserver selbst
 *                      (Target e2e in angular.json) und beendet ihn danach
 *   npx ng e2e --ui    UI-Modus: Tests auswählen, Schritt für Schritt ansehen
 *   npx playwright show-report   HTML-Bericht des letzten Laufs
 *
 * Einmalig vorher: npx playwright install chromium  (lädt den Test-Browser)
 * Ohne Internet (z. B. in Schulungs-Labs) scheitert dieser Download. Dann
 * unten bei projects die Zeile channel: 'msedge' aktivieren – Playwright
 * verwendet dann den installierten Microsoft Edge.
 *
 * → Aufbau-Handbuch „E2E-Tests mit Playwright“
 */
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  // Testdateien liegen außerhalb von src/, damit ng test (Vitest) sie nicht aufgreift
  testDir: './e2e',
  // Tests verschiedener Dateien parallel ausführen
  fullyParallel: true,
  // test.only auf dem Build-Server (CI=true) als Fehler werten
  forbidOnly: !!process.env['CI'],
  // auf dem Build-Server fehlgeschlagene Tests zweimal wiederholen
  retries: process.env['CI'] ? 2 : 0,
  reporter: [['list'], ['html', { open: 'never' }]],
  use: {
    // ng e2e setzt PLAYWRIGHT_TEST_BASE_URL auf die Adresse des gestarteten Servers;
    // page.goto('/customers') wird so zu http://localhost:4200/customers
    baseURL: process.env['PLAYWRIGHT_TEST_BASE_URL'] ?? 'http://localhost:4200',
    // Trace (Schritte, DOM, Netzwerk) nur aufzeichnen, wenn ein Test wiederholt wird
    trace: 'on-first-retry',
    locale: 'de-DE',
  },
  projects: [
    {
      name: 'chromium',
      use: {
        ...devices['Desktop Chrome'],
        // channel: 'msedge',   // installierten Microsoft Edge statt des Playwright-Browsers verwenden
      },
    },
  ],
});
