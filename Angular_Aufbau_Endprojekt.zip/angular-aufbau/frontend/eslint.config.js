// @ts-check
/*
 * eslint.config.js – Regeln für die statische Code-Analyse
 *
 * Ausführen mit: npx ng lint
 * Geprüft werden TypeScript-Dateien (inkl. Inline-Templates) und HTML-Templates.
 * → Handbuch 12.1 „Statische Analyse mit ESLint“
 */
const eslint = require('@eslint/js');
const { defineConfig } = require('eslint/config');
const tseslint = require('typescript-eslint');
const angular = require('angular-eslint');

module.exports = defineConfig([
  // Regeln für TypeScript-Dateien
  {
    files: ['**/*.ts'],
    extends: [
      eslint.configs.recommended,
      tseslint.configs.recommended,
      tseslint.configs.stylistic,
      angular.configs.tsRecommended,
    ],
    // prüft auch Templates, die inline im @Component-Decorator stehen
    processor: angular.processInlineTemplates,
    rules: {
      // Direktiven-Selektoren: Attribut mit Präfix app in camelCase, z. B. appHighlight
      '@angular-eslint/directive-selector': [
        'error',
        {
          type: 'attribute',
          prefix: 'app',
          style: 'camelCase',
        },
      ],
      // Komponenten-Selektoren: Element mit Präfix app in kebab-case, z. B. app-customer-table
      '@angular-eslint/component-selector': [
        'error',
        {
          type: 'element',
          prefix: 'app',
          style: 'kebab-case',
        },
      ],
    },
  },
  // ---------------------------------------------------------------------------
  // Architekturgrenzen (Aufbau-Handbuch „Standalone-Feature-Architektur“)
  //
  // Abhängigkeiten dürfen nur in eine Richtung zeigen:
  //   app (Routen, Konfiguration) → core → features → shared
  // - shared kennt niemanden: keine Imports aus features oder core
  // - ein Feature importiert aus einem anderen nur über dessen Einstieg
  //   ('@features/customers' lädt features/customers/index.ts), nie aus Unterordnern
  // Verstöße meldet `npx ng lint` als Fehler – die Architektur bleibt so auch
  // dann erhalten, wenn viele Leute am Projekt arbeiten.
  // ---------------------------------------------------------------------------
  {
    files: ['src/app/shared/**/*.ts'],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          patterns: [
            { group: ['@features/*', '@core/*'], message: 'shared darf weder Features noch core importieren.' },
          ],
        },
      ],
    },
  },
  {
    files: ['src/app/features/**/*.ts'],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          patterns: [
            {
              // '@features/x/irgendwas' verboten, '@features/x' (index.ts) erlaubt
              group: ['@features/*/*'],
              message: 'Andere Features nur über ihren Einstieg importieren, z. B. @features/customers.',
            },
            { group: ['@core/*'], message: 'Features dürfen core nicht importieren (core steht über den Features).' },
          ],
        },
      ],
    },
  },
  // Regeln für HTML-Templates, inklusive Barrierefreiheit (z. B. label zu input)
  {
    files: ['**/*.html'],
    extends: [angular.configs.templateRecommended, angular.configs.templateAccessibility],
    rules: {},
  },
]);
