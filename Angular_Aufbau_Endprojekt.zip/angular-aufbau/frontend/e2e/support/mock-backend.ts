/*
 * mock-backend.ts – gemeinsame Server-Mocks für die E2E-Tests (Vertiefung)
 *
 * Der Einstieg in login.spec.ts richtet seine Mocks direkt im Test ein. Sobald
 * mehrere Testdateien dieselben Mocks brauchen, lohnt sich eine Hilfsdatei
 * wie diese. customers.spec.ts verwendet sie.
 *
 * page.route() fängt Anfragen des Browsers ab, BEVOR sie das Netzwerk
 * erreichen, und beantwortet sie mit festen Daten. Vorteile:
 *   - kein laufender json-server nötig
 *   - jeder Test startet mit denselben Daten (keine Reste aus dem letzten Lauf)
 *   - Fehlerfälle lassen sich gezielt erzeugen (z. B. Status 500)
 *
 * → Aufbau-Handbuch „E2E-Tests mit Playwright“ (Erstellen von Server-Mocks)
 */
import { Page } from '@playwright/test';

/** Adresse des Backends aus environment.development.ts */
export const API = 'http://localhost:3001';

export const ADMIN = { id: 1, username: 'anna', name: 'Anna Admin', role: 'admin' };

export const CUSTOMERS = [
  { id: 1, name: 'Tim', credit_limit: 2500 },
  { id: 2, name: 'Matt', credit_limit: 500 },
  { id: 3, name: 'Dora', credit_limit: 300 },
];

/**
 * Kunden-API nachbilden: GET liefert die (veränderliche) Liste, POST hängt an.
 * Rückgabe: das Array, damit ein Test später prüfen kann, was angelegt wurde.
 */
export async function mockCustomers(page: Page, initial = CUSTOMERS) {
  const customers = initial.map((c) => ({ ...c }));
  // '**' passt auf beliebige Zeichen – erfasst /customers/ und /customers/3
  await page.route(`${API}/customers/**`, async (route) => {
    const request = route.request();
    if (request.method() === 'GET') {
      return route.fulfill({ json: customers });
    }
    if (request.method() === 'POST') {
      const created = { ...request.postDataJSON(), id: 100 + customers.length };
      customers.push(created);
      return route.fulfill({ status: 201, json: created });
    }
    // alles andere (PUT, DELETE) einfach bestätigen
    return route.fulfill({ json: {} });
  });
  return customers;
}

/**
 * Als Admin angemeldet starten, ohne das Formular auszufüllen: Den Benutzer
 * vor dem Laden der Seite in den sessionStorage legen – so wie es der AuthStore
 * (watchState in withHooks) nach einer echten Anmeldung tut.
 */
export async function loginAsAdmin(page: Page) {
  await page.addInitScript((user) => sessionStorage.setItem('crm.user', JSON.stringify(user)), ADMIN);
}
