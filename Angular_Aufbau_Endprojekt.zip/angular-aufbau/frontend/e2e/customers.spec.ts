/*
 * customers.spec.ts – E2E-Tests für die Kundenverwaltung
 *
 * Vertiefung: Alle Tests starten bereits angemeldet (loginAsAdmin) und mit
 * gemocktem Backend (mockCustomers) aus der Hilfsdatei support/mock-backend.ts.
 * Die Anmeldung selbst prüft login.spec.ts.
 *
 * → Aufbau-Handbuch „E2E-Tests mit Playwright“
 */
import { expect, test } from '@playwright/test';
import { loginAsAdmin, mockCustomers } from './support/mock-backend';

test.beforeEach(async ({ page }) => {
  await loginAsAdmin(page);
});

test('zeigt alle Kunden mit Kategorie', async ({ page }) => {
  await mockCustomers(page);
  await page.goto('/customers');
  // Zeilen der Tabelle: role "row" im tbody
  const rows = page.locator('tbody').getByRole('row');
  await expect(rows).toHaveCount(3);
  await expect(rows.first()).toContainText('Tim');
  await expect(rows.first()).toContainText('2.500,00 €');
  await expect(rows.first().getByText('A', { exact: true })).toBeVisible();
});

test('filtert die Liste über das Suchfeld', async ({ page }) => {
  await mockCustomers(page);
  await page.goto('/customers');
  await page.getByLabel('Suche nach Namen').fill('do');
  const rows = page.locator('tbody').getByRole('row');
  await expect(rows).toHaveCount(1);
  await expect(rows).toContainText('Dora');
  await expect(page.getByText('1 von 3 Kunden')).toBeVisible();
});

test('legt einen Kunden an', async ({ page }) => {
  const customers = await mockCustomers(page);
  await page.goto('/customers');
  await page.getByRole('link', { name: 'Neuer Kunde' }).click();
  await expect(page).toHaveURL(/\/customers\/new$/);

  await page.getByLabel('Name').fill('Neue GmbH');
  await page.getByLabel('Kreditlimit (EUR)').fill('1500');
  await page.getByRole('button', { name: 'Jetzt anlegen' }).click();

  // zurück in der Liste, der neue Kunde ist da
  await expect(page).toHaveURL(/\/customers$/);
  await expect(page.locator('tbody')).toContainText('Neue GmbH');
  // und der Mock hat die richtigen Daten bekommen
  expect(customers.at(-1)).toMatchObject({ name: 'Neue GmbH', credit_limit: 1500 });
});

test('zeigt eine Meldung, wenn der Server nicht antwortet', async ({ page }) => {
  // eigener Mock nur für diesen Test: jede Kunden-Anfrage scheitert mit 500
  await page.route('http://localhost:3001/customers/**', (route) => route.fulfill({ status: 500, body: 'Fehler' }));
  await page.goto('/customers');
  await expect(page.getByRole('alert')).toContainText('Kunden konnten nicht geladen werden');
});
