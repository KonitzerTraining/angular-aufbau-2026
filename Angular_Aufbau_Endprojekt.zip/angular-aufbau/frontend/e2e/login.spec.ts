/*
 * login.spec.ts – der Einstieg in die E2E-Tests: Anmeldung und Guard
 *
 * Aufbau jedes Tests:
 *   1. Server-Mock einrichten (page.route)
 *   2. Seite öffnen (page.goto)
 *   3. wie ein Mensch bedienen: Elemente über die Locator API finden
 *      (getByRole, getByLabel) und damit interagieren
 *   4. Erwartungen prüfen (expect … toBeVisible, toHaveURL …)
 *
 * Locator nach Rolle und Beschriftung statt CSS-Klassen: Sie brechen nicht,
 * wenn sich das Styling ändert, und prüfen nebenbei die Barrierefreiheit.
 *
 * → Aufbau-Handbuch „E2E-Tests mit Playwright“
 */
import { expect, test } from '@playwright/test';

test('Anmelden zeigt den Namen', async ({ page }) => {
  // Mock: Die Anmeldung fragt GET /users?username=…&password=… ab.
  // page.route() beantwortet die Anfrage, bevor sie das Netzwerk erreicht –
  // ein laufender json-server ist nicht nötig.
  await page.route('**/users?**', (route) =>
    route.fulfill({ json: [{ id: 1, username: 'anna', name: 'Anna Admin', role: 'admin' }] }),
  );

  await page.goto('/login');
  // getByLabel findet das Eingabefeld über sein <label for="…">
  await page.getByLabel('Benutzername').fill('anna');
  await page.getByLabel('Kennwort').fill('geheim');
  await page.getByRole('button', { name: 'Anmelden' }).click();

  // toHaveText wartet automatisch, bis der Text erscheint (Auto-Waiting)
  await expect(page.getByTestId('current-user')).toHaveText('Anna Admin');
});

test('falsches Kennwort zeigt eine Fehlermeldung', async ({ page }) => {
  // Mock: kein Benutzer passt – json-server liefert dann eine leere Liste
  await page.route('**/users?**', (route) => route.fulfill({ json: [] }));

  await page.goto('/login');
  await page.getByLabel('Benutzername').fill('anna');
  await page.getByLabel('Kennwort').fill('falsch');
  await page.getByRole('button', { name: 'Anmelden' }).click();

  // role="alert" aus dem Template der Login-Seite
  await expect(page.getByRole('alert')).toHaveText('Benutzername oder Kennwort ist falsch.');
});

test('/customers ohne Anmeldung leitet zu /login um', async ({ page }) => {
  await page.goto('/customers');
  // der authGuard leitet um; toHaveURL wartet, bis die URL passt
  await expect(page).toHaveURL(/\/login$/);
  await expect(page.getByRole('heading', { name: 'Anmelden' })).toBeVisible();
});
