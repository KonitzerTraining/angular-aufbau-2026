# Angular Aufbau · CRM-Referenzprojekt

Begleitprojekt zur Schulung **„Angular Aufbau“** (DRV, 23.–25.11.2026). Es setzt das CRM aus der Schulung „Angular Grundlagen“ (Stand `v1.1`) fort.

Die Fassung mit Angular 22: NgRx 22, OnPush als Standard, **SignalStore für Kunden und Anmeldung** und **Signal Forms** für das Kundenformular.

**Stand: Endprojekt (4.0.0, 25.11.2026)** – alles, was im Seminar entsteht.

Es gibt zwei Stände:

- **Startprojekt:** das CRM aus Angular Grundlagen v1.1 auf Angular 22, mit einer Login-Seite ohne Logik. Von hier aus bauen Sie im Seminar die Anwendung aus.
- **Endprojekt:** Standalone-Feature-Architektur mit Lazy Loading, Unit-Tests mit Vitest und ng-mocks, NgRx SignalStore für Kunden und Anmeldung, Signal Forms für das Kundenformular, Login mit Reactive Forms, funktionale Guards und E2E-Tests mit Playwright.

Beide Stände gibt es als ZIP: `Angular_Aufbau_Startprojekt.zip` und `Angular_Aufbau_Endprojekt.zip`.

Der Code ist ausführlich kommentiert. Verweise wie `→ Handbuch 9.5 „Der CustomerService“` beziehen sich auf das Handbuch „Angular Grundlagen“ v1.1, Verweise wie `→ Aufbau-Handbuch „Signal Forms“` auf das Handbuch „Angular Aufbau“ ab Version 4.0.

```
├── frontend/   Angular-22-Anwendung (ng new frontend): Tailwind CSS 4, Signals, Routing, Reactive Forms, Vitest, ESLint
└── backend/    REST-API mit json-server (Port 3001)
```

## Starten

```bash
# Terminal 1 – Backend
cd backend
npm install
npm start          # http://localhost:3001/customers

# Terminal 2 – Frontend
cd frontend
npm install
npm start          # http://localhost:4200
```

Voraussetzung: Node.js 22.22 oder 24.15 oder neuer (Angular 22; getestet mit Node.js 24.16).

VS Code verwendet dank `frontend/.vscode/settings.json` die TypeScript-Version des Projekts. Fragt VS Code beim Öffnen nach, bestätigen Sie „Allow“. Sind Pfad-Aliase trotzdem rot, obwohl `ng build` läuft: „TypeScript: Select TypeScript Version“ → „Use Workspace Version“ und danach „TypeScript: Restart TS Server“.

## Befehle im Frontend

| Befehl | Zweck |
|---|---|
| `npm start` | Entwicklungsserver mit Live Reload |
| `npm test` | Unit-Tests mit Vitest im Watch-Modus |
| `npm run test:ci` | Unit-Tests einmal ausführen |
| `npm run test:coverage` | Unit-Tests mit Code-Abdeckung, Bericht in `coverage/` (Mindestwerte in `angular.json`) |
| `npm run e2e` | E2E-Tests mit Playwright über `ng e2e` (startet den Entwicklungsserver selbst, das Backend wird gemockt) |
| `npm run e2e:ui` | Playwright im UI-Modus |
| `npm run lint` | Codequalität mit ESLint |
| `npm run build` | Produktions-Build nach `dist/frontend/browser` (mit `<base href="./">`) |
| `npm run preview` | Build mit http-server auf Port 8080 testen; API-Anfragen gehen an das Backend |

Vor dem ersten E2E-Lauf lädt `npx playwright install chromium` den Test-Browser. Ohne Internet scheitert das; dann in `playwright.config.ts` die Zeile `channel: 'msedge'` aktivieren, und Playwright verwendet den installierten Microsoft Edge.

## Aufbau

Die Feature-Architektur ist in [frontend/src/app/ARCHITEKTUR.md](frontend/src/app/ARCHITEKTUR.md) beschrieben:

- `core/` – Rahmen der Anwendung (Navigation, abhängig vom Login-Zustand)
- `pages/` – kleine Seiten (Start, Über uns, 404)
- `features/customers/` – Kundenverwaltung: `model` (Interfaces und Typen), `data-access` (Service, **CustomerStore** mit NgRx SignalStore), `ui`, `views`, `testing`, `index.ts` als öffentliche Schnittstelle
- `features/auth/` – Anmeldung: `model/user.ts`, `data-access/auth-store.ts` (AuthStore), `auth-service.ts` (Anmeldung gegen das Mock-Backend), Login-Seite mit Reactive Forms, Guards
- `features/playground/` – Übungsseiten aus dem Grundlagenkurs (`/playground/template-syntax`, `/playground/signals`)
- `shared/` – fachneutrale Bausteine (`ui`, `directives`, `pipes`)
- Pfad-Aliase `@core/…`, `@shared/…`, `@features/…`, `@env/…`; ESLint prüft die Grenzen zwischen den Ebenen

## Angular DevTools

Die Browser-Erweiterung „Angular DevTools“ (Chrome, Edge, Firefox) zeigt die Komponenten und ihre Signals, also auch den Zustand von CustomerStore und AuthStore.

## Daten zurücksetzen

json-server schreibt alle Änderungen in `backend/db.json`. Ausgangsstand wiederherstellen: Server stoppen und `backend/db.start.json` über `backend/db.json` kopieren.

Kunden- und Benutzerdaten sind erfunden. Testbenutzer für den Login stehen unter `users` in `backend/db.json` (nur für das Mock-Backend gedacht).
